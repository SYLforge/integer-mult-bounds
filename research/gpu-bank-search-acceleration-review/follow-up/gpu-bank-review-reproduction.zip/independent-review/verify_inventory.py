"""Check every shipped file against its SHA-256, from a directory or a ZIP."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile


def check(get):
    data=json.loads(get("independent-review/PACKAGE-MANIFEST.json"))
    for name, expected in data["sha256"].items():
        actual=hashlib.sha256(get(name)).hexdigest()
        if actual != expected:
            raise ValueError(f"SHA-256 mismatch: {name}")
    return len(data["sha256"])


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip",type=Path)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent.parent)
    args=parser.parse_args()
    if args.zip:
        with ZipFile(args.zip) as archive:
            n=check(archive.read)
            if len(archive.namelist())!=n+1:
                raise ValueError("Unexpected file count")
    else:
        n=check(lambda f:(args.root/f).read_bytes())
    print(f"Verified {n} shipped file hashes.")

