# Reproduction on Windows

The archive contains the review scripts, a read-only results snapshot, the synthetic test graph, and immutable URLs and hashes for external sources. Extract it into a fresh directory. The scripts expect the `independent-review` directory immediately below the extraction root.

Use 64-bit Windows PowerShell, a 64-bit Python executable, NumPy, CUDA-enabled PyTorch, an NVIDIA driver and NVRTC for the installed GPU architecture. The observed environment was Windows 11, Python 3.13.14, NumPy 2.5.4, PyTorch 2.14.1+cu130, RTX 5080 and driver 621.14. The scorer loads NVRTC from the torch library directory or the toolkit's CUDA_PATH. Keep the output directory fresh. The commands below only write local files. Run the following from the extraction root, replacing the executable path.

```powershell
$py = 'C:\path\to\python.exe'
.\independent-review\REPLAY.ps1 -PythonExe $py -Threads 4 -OutputDirectory .\my-review-results
```

The command fetches 29 pinned public files, verifies both SHA-256 and Git blob IDs, runs the positive and buffer controls, compares every public candidate against the two CPU oracles, and times all 36 fresh processes. The default worker count matches the measured setting. The report for each timed process and the exact argument vector are retained. Allow several minutes on comparable hardware. The time comparison excludes the separate row-level audits.

For an offline replay after fetching, add `-Offline`. To run the optional staged PyTorch investigation, add `-TorchDiagnostic`. A lightweight check of the diagnostic's frozen inputs and archived measurements is available separately.

```powershell
& $py -I -B .\independent-review\bootstrap_inputs.py --workspace .
& $py -I -B .\independent-review\bootstrap_inputs.py --workspace . --offline
& $py -I -B .\independent-review\torch_portable.py --check
```

Check the archive inventory from the extraction root before adding any new files.

```powershell
& $py -I -B .\independent-review\verify_inventory.py
```

The two measured runs use the public fork's review directory at `633e1db0d750299a29075d65d66607bcd73b4518`. The first rational graph is pinned to `172475c2ca321d3496fda7a2a71478ada5acb948`. The second is pinned to `787cdddaa7f32b05c44452b8c52a376b600b5348`. Computed canonical hashes, byte hashes, owner attribution and credit are recorded in `bootstrap-inputs.json`, `review-provenance.json` and the upstream notices. The historical search has its own optional fetch/replay procedure. [Historical replay](HISTORICAL-REPLAY.md)

The external public WORD/LAYOUT, the original verifier sources, PyTorch, GPU binaries and driver are obtained from their original sources or the user's installed environment. The archive includes the notices and Apache-2.0 license associated with the source works. The recorded commands in the shareable snapshot use placeholders for the measured machine's personal file paths; the local originals retain exact paths. The substitute paths affect display only. The synthetic WORD, layout and child are review controls with one owner. The finite P104 application was not run on that control.

[Review fork and original comparator](https://github.com/SYLforge/integer-mult-bounds/tree/633e1db0d750299a29075d65d66607bcd73b4518/research/gpu-bank-search-acceleration-review) · [First #7786 package](https://github.com/CrocSwap/integer-mult-bounds/tree/172475c2ca321d3496fda7a2a71478ada5acb948/research/p104-iterated-returns) · [Second #7786 package](https://github.com/CrocSwap/integer-mult-bounds/tree/787cdddaa7f32b05c44452b8c52a376b600b5348/research/p104-iterated-returns) · [Project notice](https://github.com/CrocSwap/integer-mult-bounds/blob/787cdddaa7f32b05c44452b8c52a376b600b5348/research/p104-iterated-returns/NOTICE)

