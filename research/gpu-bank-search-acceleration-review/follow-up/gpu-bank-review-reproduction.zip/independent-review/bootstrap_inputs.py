"""Retrieve immutable public prerequisites into a review workspace or verify them offline."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


MANIFEST = Path(__file__).with_name('bootstrap-inputs.json')


def checked(data, item):
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\x00' + data).hexdigest()
    if hashlib.sha256(data).hexdigest() != item['sha256'] or blob != item['git_blob']:
        raise ValueError('Mismatched input: ' + item['destination'])
    if 'canonical' in item:
        value = json.loads(gzip.decompress(data))
        canonical = json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
        if hashlib.sha256(canonical).hexdigest() != item['canonical']:
            raise ValueError('Mismatched canonical object: ' + item['destination'])


def materialize(root, item, offline):
    path = (root / item['destination']).resolve()
    if not path.is_relative_to(root):
        raise ValueError('Unsafe local path')
    if path.is_file():
        checked(path.read_bytes(), item)
        return
    if offline:
        raise FileNotFoundError(path)
    url = item['url']
    parsed = urlsplit(url)
    parts = parsed.path.split('/')
    if (parsed.scheme != 'https' or parsed.netloc != 'raw.githubusercontent.com' or len(parts) < 5
            or len(parts[3]) != 40 or any(c not in '0123456789abcdef' for c in parts[3])):
        raise ValueError('Expected an immutable GitHub URL')
    with urlopen(Request(url, headers={'User-Agent':'public-bank-search-replay'}), timeout=60) as response:
        data = response.read()
    checked(data, item)
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile(dir=path.parent, delete=False) as f:
        f.write(data)
        temporary = Path(f.name)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workspace', type=Path, default=Path(__file__).resolve().parent.parent,
                   help='destination containing independent-review/ and public-787cddda/')
    p.add_argument('--offline', action='store_true', help='only verify previously downloaded files')
    args = p.parse_args()
    entries = json.loads(MANIFEST.read_bytes())['files']
    root = args.workspace.resolve()
    with ThreadPoolExecutor(max_workers=4) as executor:
        list(executor.map(lambda item: materialize(root, item, args.offline), entries))
    print(f'Verified {len(entries)} immutable files ({len(set(e["sha256"] for e in entries))} unique SHA-256 hashes).')


if __name__ == '__main__':
    main()
