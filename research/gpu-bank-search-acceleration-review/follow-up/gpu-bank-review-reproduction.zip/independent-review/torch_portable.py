"""Compare fresh legacy PyTorch runs using the prepared 633e1db0 public review package.

From the extracted directory run python -I -B independent-review/bootstrap_inputs.py first.
The --check option verifies pinned public inputs and prints the published wall-time vectors
without loading NumPy, PyTorch or CUDA. --out is a fresh directory for the actual run.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import torch_stages as probe

AUDIT_SHA = 'fc03b6bec9bec6a81a727ad2005831d8f091b476bea328e9c1b5fbe698587307'
BENCH_SHA = '4e78cc4086fa3ff067e3e042434271169be241ff3f1e9eba81ab8740f57c411f'


def load(path):
    return json.loads(path.read_bytes())


def check_package(root):
    legacy = root / 'multibank-latest-round-20261119'
    inputs = root / 'gpu-cpu-search-pilot-20261119/snapshot-172475c2/complex'
    audit_file, bench_file = [root / 'evidence' / name for name in ('audit-final.json', 'benchmark.json')]
    if probe.sha(audit_file) != AUDIT_SHA or probe.sha(bench_file) != BENCH_SHA:
        raise ValueError('Public audit or benchmark receipt hash differs from revision 633e1db0')
    audit, bench = load(audit_file), load(bench_file)
    if {name:probe.sha(legacy/name) for name in audit['legacy_source_sha256']} != audit['legacy_source_sha256']:
        raise ValueError('Legacy implementation differs from the audited public source hashes')
    if {name:probe.sha(inputs/name) for name in probe.EXPECTED} != probe.EXPECTED:
        raise ValueError('Compressed public word or layout differs')
    if bench['compressed_input_sha256'] != probe.EXPECTED or audit['kappa'] != probe.KAPPA:
        raise ValueError('Public input pins differ from diagnostic input')
    return legacy, inputs, audit, bench


def decisions(report):
    return {key: report[key] for key in probe.COMPARED}


def main(args):
    root = args.package.resolve()
    probe.ORIGINAL, probe.SNAPSHOT, audit, bench = check_package(root)
    vectors = {kind: [r['process_wall_s'] for r in bench['runs'] if r['backend'] == kind and r['exit_code'] == 0]
               for kind in ('cpu','cuda','new')}
    summary = dict(public_package_commit='633e1db0d750299a29075d65d66607bcd73b4518',
                   benchmark_commit=bench['benchmark_commit'], fixed=probe.EXPECTED, package=str(root),
                   historical_source='Public review evidence/benchmark.json, 18 completed cold processes.',
                   published_wall_vectors_s=vectors, published_wall_medians_s=bench['medians_s'],
                   benchmark_receipt_sha256=BENCH_SHA, audit_receipt_sha256=AUDIT_SHA,
                   portable_driver_sha256=probe.sha(Path(__file__)), instrument_sha256=probe.sha(Path(probe.__file__)),
                   original_instrument_sha256='7ffa45ba78bf680735a439892a697d4b534ecc6ba104be4a3f4e896fed0ca41b',
                   legacy_sha256=audit['legacy_source_sha256'])
    if args.archived_diagnostic:
        archive = load(args.archived_diagnostic)
        summary['optional_prior_diagnostic'] = {
            'sha256':probe.sha(args.archived_diagnostic), 'path':str(args.archived_diagnostic.resolve()),
            'first_batch':archive['first_batch'], 'remaining_batches':archive['remaining_batches'],
            'wall_s':[r['wall_s'] for r in archive['runs']], 'untouched_score_s':archive['untouched_score_s']}
    if args.check:
        print(json.dumps(summary, indent=2))
        return
    if args.out is None:
        raise ValueError('Supply --out NEW_DIRECTORY for a timed run, or --check for a read-only check')
    out = args.out.resolve()
    if args.staged_worker:
        probe.staged(out)
        return
    out.mkdir(exist_ok=False, parents=True)
    summary.update(start=probe.now(), status='running', runs=[])
    receipt = out/'diagnostic.json'
    probe.write(receipt, summary)
    try:
        for mode in ('untouched', 'staged'):
            command = ([sys.executable, '-I', '-B', str(probe.ORIGINAL/'fused_search.py'), *probe.args_for(out/mode)]
                       if mode == 'untouched' else
                       [sys.executable, '-I', '-B', str(Path(__file__).resolve()), '--staged-worker',
                        '--package', str(root), '--out', str(out)])
            entry = dict(mode=mode, command=command, utc=probe.now(), gpu_before=probe.snapshot_gpu(), exit_code=None)
            summary['runs'].append(entry)
            probe.write(receipt, summary)
            log = out/(mode+'.log')
            with log.open('wb') as stream:
                t = perf_counter()
                process = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
                wall = perf_counter()-t
            entry.update(wall_s=wall, exit_code=process.returncode, gpu_after=probe.snapshot_gpu(),
                         log_sha256=probe.sha(log))
            probe.write(receipt, summary)
            process.check_returncode()
        raw, staged = [load(out/mode/'report.json') for mode in ('untouched','staged')]
        records = audit['boundary_records']
        expected = dict(baseline_graph=audit['canonical_graph_sha256'], kappa=audit['kappa'],
                        total_connected_motifs=audit['motif_census'], nonexcluded_motifs=audit['nonexcluded_motifs'],
                        selected_motifs=audit['selected_motifs'], options_limit=audit['options_limit'],
                        assignments_scored=audit['rows_compared_elementwise'],
                        uncertain_or_positive_assignments_checked_by_exact_histogram=len(records),
                        unique_histograms=len({tuple(r['delta']) for r in records}), positive_examples=[])
        if audit['positives'] != 0 or decisions(raw) != decisions(staged) or decisions(raw) != expected:
            raise ValueError('Untouched, staged and public candidate counts or decisions disagree')
        stages = load(out/'stages.json')
        if sum(row['rows'] for row in stages['batches']) != raw['assignments_scored']:
            raise ValueError('Incomplete stage coverage')
        summary.update(status='pass', end=probe.now(), outputs_agree=True,
                       first=stages['first'], first_batch=stages['batches'][0],
                       imports_s={k:v for k,v in stages.items() if 'import' in k},
                       remaining_batches=stages['sums_after_first_batch'], staged_total=stages['stage_sums'],
                       untouched_score_s=raw['gpu_transfer_score_return_s'], stages_sha256=probe.sha(out/'stages.json'),
                       scope='The staged diagnostic adds device synchronization. Its cold child wall also includes input and receipt hash checks. Wall-time vectors are from the public machine; historical per-stage observations are optional.')
    except Exception as exc:
        summary.update(status='incomplete', error=str(exc))
        raise
    finally:
        probe.write(receipt, summary)
    print(json.dumps({k:summary[k] for k in ('outputs_agree','first_batch','remaining_batches','untouched_score_s')},
                     indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=HERE/'review-633e1db0',
                        help='materialized public package containing legacy, evidence and snapshot inputs')
    parser.add_argument('--out', type=Path, help='fresh output directory for the two cold CUDA runs')
    parser.add_argument('--check', action='store_true', help='validate inputs and receipts without exercising CUDA')
    parser.add_argument('--archived-diagnostic', type=Path,
                        help='optional prior local diagnostic.json to include for stage comparison')
    parser.add_argument('--staged-worker', action='store_true', help=argparse.SUPPRESS)
    main(parser.parse_args())
