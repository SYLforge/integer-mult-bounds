param(
    [string]$PythonExe = 'python',
    [int]$Threads = 4,
    [string]$OutputDirectory = ('review-replay-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')),
    [switch]$Offline,
    [switch]$TorchDiagnostic
)
$ErrorActionPreference = 'Stop'
$code = $PSScriptRoot
$workspace = Split-Path -Parent $code
$reportRoot = (New-Item -ItemType Directory -Path $OutputDirectory).FullName
function Invoke-ReviewPython {
    & $PythonExe -I -B @args
    if ($LASTEXITCODE -ne 0) { throw "Python exited with $LASTEXITCODE." }
}
$bootstrapFlags = @('--workspace', $workspace)
if ($Offline) { $bootstrapFlags += '--offline' }
Invoke-ReviewPython "$code/bootstrap_inputs.py" @bootstrapFlags
$second = Join-Path $workspace 'public-787cddda/complex'
Invoke-ReviewPython "$code/fixture_audit.py" --out "$reportRoot/fixture"
Invoke-ReviewPython "$code/differential.py" --pin 172475c2 --threads $Threads --out "$reportRoot/audit-172475c2.json"
Invoke-ReviewPython "$code/differential.py" --pin 787cddda --input-dir $second --threads $Threads --out "$reportRoot/audit-787cddda.json"
Invoke-ReviewPython "$code/bench_two.py" --second-dir $second --threads $Threads --blocks 6 --out "$reportRoot/timing"
Invoke-ReviewPython "$code/analyze_timing.py" --timing "$reportRoot/timing" --out "$reportRoot/timing-summary.json"
if ($TorchDiagnostic) {
    Invoke-ReviewPython "$code/torch_portable.py" --out "$reportRoot/torch"
}
Write-Output $reportRoot

