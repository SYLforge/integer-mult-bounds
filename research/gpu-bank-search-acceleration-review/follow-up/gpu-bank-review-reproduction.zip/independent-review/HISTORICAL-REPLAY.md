# Public predecessor search

The 16 complete searches covered 511,212 connected motifs and 2,933,212,387 assignments. The GPU returned 121 near-threshold assignments for CPU rational rank-histogram pricing. None had positive native paid credit at κ = 0.00387561167742. Each search retained 24 exterior-ranked chart options per bank plus the original special charts, required at least three changed banks, and fixed all independent public endpoints.

There are sixteen different canonical words, sixteen word/layout pairs, six layouts and five source/export commits. The #7767 and #7776 stages are intermediate words authenticated by the published edit journals. Some changes affect scalar coefficients without changing the chart-choice search space. Assignment counts therefore describe work performed on each input. The total does not measure globally unique transformations.

The #7781 packed WORD is the pure-birth intermediate declared in its claim. The earlier 10,000-motif prefixes are omitted from aggregate counts. Their results, the initial pin check, and the SHA-256 of each exact boundary stream are in historical-coverage.json.

## Standalone Windows replay

Place historical_relocation.py, historical_coverage.py, fetch_early_exports.py, fetch_review.py and historical-coverage.json together in a writable directory. In that directory, use 64-bit Python 3.12, NumPy and a CUDA-capable NVIDIA device with NVRTC. The public decoder uses the CUDA driver and NVRTC. Positive-witness graph reconstruction imports the original PyTorch reference. The prior RTX tests used the embedded Python listed in the review's top-level instructions.

Set `$py` to the absolute Python executable, then run the following PowerShell commands. Use fresh output directories. The first two commands retrieve the immutable public search implementation and the early graph exports. The third fetches the two pinned #7786 source-loader files and invokes the original loader, verifying every locked dependency by SHA-256 and Git blob ID.

```powershell
& $py -I -B fetch_review.py
& $py -I -B fetch_early_exports.py
& $py -I -B historical_relocation.py --which basic --limit 999999 --out repeat-basic --cache public-source-cache --fetch-sources
& $py -I -B historical_relocation.py --which earlier --limit 999999 --max-cases 12 --out repeat-early --cache public-source-cache
& $py -I -B historical_relocation.py --which exports --limit 999999 --out repeat-earliest
& $py -I -B historical_coverage.py --folders repeat-basic repeat-early repeat-earliest --preliminary --compare historical-coverage.json --out repeat-summary.json
```

In the original workspace, the pre-existing source cache is one directory above independent-review. Pass `--cache ../public-source-cache` and omit `--fetch-sources` to reuse those inputs. Each canonical word/layout pair is checked on load. For the #7776 journal stages, the supplier's public-owner layout rule appends consecutive new owner labels, while the public journal authenticates each new word hash.

The exploratory runs loaded the benchmark implementation from the task workspace. The portable driver loads the immutable review commit `633e1db0d750299a29075d65d66607bcd73b4518` from review-633e1db0/work/benchmark. The imported kernel and Python implementation were compared with the measured copies. The two files with different raw bytes differed only in final blank lines. The positive-only path delegates synthesis and pricing to the public reference multibank_search.py and compares the dense rational endpoint operator using the original #7781 reader. The historical sweeps produced no positive and did not enter that path. The final comparison ignores run timings and compares exact hashes, counts, motif census and ordered boundary records.

For a direct 10,000-motif comparison on the two oldest graphs, run `historical_relocation.py --which exports --out repeat-earliest-top` with the same Python. Source URLs and compressed/canonical hashes for #7713 and #7726 are in the two export provenance files. Pinned #7786 uses CrocSwap/integer-mult-bounds commit `787cdddaa7f32b05c44452b8c52a376b600b5348`, subdirectory `research/p104-iterated-returns`.

[Immutable review package](https://github.com/SYLforge/integer-mult-bounds/tree/633e1db0d750299a29075d65d66607bcd73b4518/research/gpu-bank-search-acceleration-review) · [Locked public scientific sources](https://github.com/CrocSwap/integer-mult-bounds/tree/787cdddaa7f32b05c44452b8c52a376b600b5348/research/p104-iterated-returns)
