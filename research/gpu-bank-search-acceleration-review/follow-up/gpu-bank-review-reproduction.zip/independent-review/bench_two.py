"""Six permutations per input, fresh processes; no concurrent CPU/GPU trial."""
import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parent
REVIEW = ROOT / "review-633e1db0"
SCRIPTS = {
    "legacy_cpu": REVIEW / "multibank-latest-round-20261119/fused_search.py",
    "fast_cpu": ROOT / "run_cpu.py",
    "fast_gpu": REVIEW / "work/benchmark/fast_search.py",
}
ORDER = [
    ("legacy_cpu", "fast_cpu", "fast_gpu"), ("fast_cpu", "fast_gpu", "legacy_cpu"),
    ("fast_gpu", "legacy_cpu", "fast_cpu"), ("fast_gpu", "fast_cpu", "legacy_cpu"),
    ("legacy_cpu", "fast_gpu", "fast_cpu"), ("fast_cpu", "legacy_cpu", "fast_gpu"),
]
PINS = {
    "172475c2": ("172475c2ca321d3496fda7a2a71478ada5acb948", "0.00387561167742",
                 "341c49e9b9d6e8742f948cba2407f7ad67164f87f4191c21319730cfc8b419d3",
                 "5bd55b71fd1757a2c907bdc2a32f69e29b38f960fa95b67780842502888e2364"),
    "787cddda": ("787cdddaa7f32b05c44452b8c52a376b600b5348", "0.00387827242155",
                 "46ea629a4698a96df7664d9f36019cbd181e80985b512edff2bef0e0ca981a52",
                 "9ef2bcefc0f77ad98eb33da88f4f488d102d1529ab6b6004b298d182bd52b3ec"),
}
FIELDS = ("baseline_graph", "kappa", "selected_motifs", "total_connected_motifs",
          "nonexcluded_motifs", "options_limit", "assignments_scored", "unique_histograms",
          "uncertain_or_positive_assignments_checked_by_exact_histogram")
def utc():
    return datetime.now(timezone.utc).isoformat()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--second-dir", type=Path, required=True, help="folder containing pinned WORD/LAYOUT")
    p.add_argument("--threads", type=int, default=12)
    p.add_argument("--blocks", type=int, choices=(3,6), default=6)
    a = p.parse_args()
    paths = {"172475c2": REVIEW / "gpu-cpu-search-pilot-20261119/snapshot-172475c2/complex",
             "787cddda": a.second_dir.resolve()}
    for tag, path in paths.items():
        for name,pin in zip(("WORD.json.gz","LAYOUT.json.gz"),PINS[tag][2:]):
            if hashlib.sha256((path/name).read_bytes()).hexdigest() != pin:
                raise ValueError(f"Input differs: {tag}/{name}")
    dest = a.out.resolve()
    dest.mkdir(exist_ok=False, parents=True)
    benchmark = dict(start_utc=utc(), python=sys.version, executable=sys.executable,
                     cpu_threads_requested=a.threads, logical_processors=os.cpu_count(),
                     process_timing="parent perf_counter around subprocess.run, including interpreter and exit",
                     pins=PINS, runs=[], run_order="all six permutations per input; input alternates first by block")
    expected = {}
    def save():
        (dest/"timing.json").write_text(json.dumps(benchmark, indent=2)+"\n",encoding="utf-8")

    for b, order in enumerate(ORDER[:a.blocks]):
        tags = list(paths)
        if b % 2:
            tags.reverse()
        for tag in tags:
            # Reverse the permutation on the second input to decorrelate engine position.
            engines = order if tag == "172475c2" else order[::-1]
            for backend in engines:
                label = f"{len(benchmark['runs'])+1:02d}-{tag}-{backend}"
                cmd = [sys.executable,"-I","-B",str(SCRIPTS[backend]),
                       "--graph",str(paths[tag]/"WORD.json.gz"),
                       "--layout",str(paths[tag]/"LAYOUT.json.gz"),
                       "--kappa",PINS[tag][1],"--motifs","10000","--options","24",
                       "--out",str(dest/label)]
                if backend == "legacy_cpu":
                    cmd += ["--backend","cpu"]
                if backend == "fast_cpu":
                    cmd += ["--threads",str(a.threads)]
                started = utc()
                tick = perf_counter()
                proc = subprocess.run(cmd,cwd=ROOT,capture_output=True)
                elapsed = perf_counter()-tick
                (dest/(label+".log")).write_bytes(proc.stdout+b"\n"+proc.stderr)
                run = dict(backend=backend,input=tag,command=cmd,exit_code=proc.returncode,
                           start_utc=started,process_wall_s=elapsed,report=label+"/report.json")
                benchmark["runs"].append(run)
                save()
                if proc.returncode:
                    raise RuntimeError((proc.stderr or proc.stdout).decode(errors="replace"))
                r = json.loads((dest/run["report"]).read_bytes())
                state = {k:r[k] for k in FIELDS}
                state["positive_count"] = len(r["positive_examples"])
                if tag not in expected:
                    expected[tag] = state
                if expected[tag] != state:
                    raise ValueError((label, expected[tag], state))
                print(label, f"{elapsed:.4f} s", flush=True)
    benchmark["results"]={}
    for tag in paths:
        times={engine:[r["process_wall_s"] for r in benchmark["runs"]
                       if r["input"]==tag and r["backend"]==engine] for engine in SCRIPTS}
        med={k:statistics.median(v) for k,v in times.items()}
        benchmark["results"][tag] = dict(median_s=med,range_s={k:[min(v),max(v)] for k,v in times.items()},
                         fast_cpu_divided_by_fast_gpu=med["fast_cpu"]/med["fast_gpu"],
                         legacy_cpu_divided_by_fast_gpu=med["legacy_cpu"]/med["fast_gpu"],
                         legacy_cpu_divided_by_fast_cpu=med["legacy_cpu"]/med["fast_cpu"], scope=expected[tag])
    benchmark["end_utc"] = utc()
    save()
    print(json.dumps(benchmark["results"],indent=2))


if __name__ == "__main__":
    main()

