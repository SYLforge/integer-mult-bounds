# Positive and all-hit controls

Run from this directory using the same Python installation as the pinned GPU package.

```powershell
& $PythonExe -I -B .\fixture_audit.py --out .\fixture-repeat
```

The output directory must be new. The runner reads `review-633e1db0` and the pinned public source cache in the parent directory. Paths can be supplied with `--review-package` and `--source-cache`. The single-owner graph and transformed word are saved with the result when running the small fixture.

## Geometric tariff control

The small word passes one independent owner through four rational forms with coefficient one on nested coordinate subspaces over a nine-bit ambient space. Three unconstrained banks have ranks 2, 4, 6. The input and output remain fixed at ranks 0 and 9. Changing the free ranks to 1, 2, 3 gives the exact symbolic saving

```text
3 H(2) + H(3) − 3 H(1) − H(6),   H(r) = r^(1−κ).
```

The checker reprices the whole reconstructed word, compares it with the per-row 90-digit Decimal calculation, and tests the reverse edit. The unmodified public reader checks rational forward and adjoint maps, donor-chart causality, strict subspace nesting and charged rank histograms. Each physical chart conversion is lowered by the public Clifford code. Its signed tableau and absolute phase are compared with the public independent chart representation, for each paid pair and both complete ordered compositions. An exact Clifford tableau together with absolute phase determines the whole unitary. The scalar identity is between different physical endpoint charts; the physical map in this example is the rank-zero-to-nine conversion. This one-owner word does not instantiate the 104-port public application.

The unrestricted small-graph audit uses all options and checks every GPU and fast CPU row against the original fused CPU score and the direct incidence CPU score. It compares every recovered boundary ordinal and runs the original exact predicate on each boundary row. The legacy CLI's positive examples coalesce equal histograms within a motif chunk, so class witnesses and per-assignment decisions are checked separately. An additional `κ=1e-20` control has a strictly adverse reverse edit that rounds to zero and therefore requires exact rejection. The inclusive shortlist cutoff is probed at one unit below, at, and one unit above with explicitly artificial integer baselines.

## Buffer capacity

The batch has `size` candidate rows and `capacity >= size` result slots. Each participating GPU thread handles one distinct ordinal and makes at most one atomic increment. A return occurs before the increment for every out-of-range launch thread. Thus the pre-increment indices of writes are at most `size−1`. The host permits `batch_size <= 2^29−1`, below the counter's unsigned 32-bit wrap point, and rejects returned counts greater than the submitted size. Two streams have separate counters and output storage. This bound holds for every density of passing rows.

The default-size test makes every valid row pass. Two independently routed chains have 81 alternatives at each of the three changed banks. These are distinct chart IDs constructed as ordered bases of the same rank-specific coordinate space. They deliberately have identical paid rank signatures, which tests ties, and no candidate repeats within a motif. The fixture restricts options to this all-hit Cartesian subdomain of each chain. It compares each chart ID, integer score, and recovered motif/ordinal against the original CPU decoder and scorers. The two 524,288-row buffers and final 14,306-row batch together contain 1,062,882 hits. The two independent motifs change at global ordinal 531,441 inside the second batch. Separate cases exercise a full one-row slot on both streams, a three-row batch with one-row tail, and exact repricing on each side of every seam.
