## How much does the GPU add to bank search after optimizing the CPU?

On one Windows 11 Ryzen 9 7900X / RTX 5080 system, sharing the faster motif preparation and using a grouped four-worker NumPy scorer brought CPU search close to CUDA. Each number below is the median of six fresh processes. We ran all six orders on each input and timed startup through report writing and exit.

| #7786 input | Legacy CPU | Optimized CPU | GPU + CPU | Optimized CPU time / GPU time |
|---|---:|---:|---:|---:|
| `172475c2` | 9.193 s | 1.260 s | 1.219 s | 1.033× |
| `787cddda` | 9.067 s | 1.270 s | 1.217 s | 1.043× |

A clean-directory replay on the same machine gave ratios of 1.038× and 1.031×, respectively.

All 53,977,655 candidate ordinals, chart tuples and integer scores agreed with the original CPU references. Each input had one exact zero and no gain. A reviewer-supplied **synthetic** four-transfer chain supplied the positive control after 16 historical graph stages yielded no positive. The nominated change saved 0.0126778389 tariff units with the same forward and adjoint maps. A dense test filled both 524,288-entry device buffers and returned every hit. **No new κ bound resulted.**

The optional CUDA path adds driver bindings, an NVRTC kernel and two-stream buffer tests to maintain. Linux, other GPUs and larger workloads remain untested. The verifier is unchanged. Reproduction fetches hash-pinned inputs from their sources and retains their Apache-2.0 notices. Credit to Clear1nsight and the #7786 contributors for the inputs and verifier, and to the authors of the earlier local comparators. OpenAI Codex assisted with this review. [Original review package](https://github.com/SYLforge/integer-mult-bounds/tree/633e1db0d750299a29075d65d66607bcd73b4518/research/gpu-bank-search-acceleration-review) · [#7786 input and attribution](https://github.com/CrocSwap/integer-mult-bounds/tree/787cdddaa7f32b05c44452b8c52a376b600b5348/research/p104-iterated-returns)

