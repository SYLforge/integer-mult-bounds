"""Run the pinned public fast-preparation path with the optimized CPU scorer."""
import argparse
from functools import partial
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "review-633e1db0/work/benchmark"
sys.path[:0] = [str(ROOT), str(PUBLIC)]
import fast_search
import cpu_score


def main():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--threads", type=int, default=12)
    args, remaining = p.parse_known_args()
    sys.argv[1:] = remaining
    fast_search.score_selected = partial(cpu_score.score_selected, threads=args.threads)
    original_round = fast_search.run_round

    def cpu_round(*values, **options):
        r = original_round(*values, **options)
        r["cpu"] = r.pop("gpu")
        r["backend"] = "fast-prep-cpu"
        return r

    fast_search.run_round = cpu_round
    fast_search.main()


if __name__ == "__main__":
    main()

