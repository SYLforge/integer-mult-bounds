"""Summarize full historical checkpoint coverage, counting each graph/layout pair once."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_text())
def fh(path):
    return sha256(path.read_bytes()).hexdigest()

def build(folders,preliminary):
    cases=[]
    indexed=set()
    for folder in folders:
        src=HERE/folder
        summary=read(src/'summary.json')
        for r in summary['cases']:
            rep=src/r['name']/'report.json'
            s=read(rep)
            key=r['parent'],r['layout']
            assert key not in indexed
            indexed.add(key)
            assert s['baseline_graph']==r['parent'] and s['assignments_scored']==r['assignments']
            assert s['selected_motifs']==s['nonexcluded_motifs']==sum(s['total_connected_motifs'].values())
            assert len(s['boundary_records'])==r['boundaries'] and len(s['positive_examples'])==r['positives']
            boundary_sha=sha256(json.dumps(s['boundary_records'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
            cases.append(dict(**r,report=str(rep.relative_to(HERE)).replace('\\','/'),report_sha256=fh(rep),boundary_stream_sha256=boundary_sha,
                census=s['total_connected_motifs'],case_sha256=fh(rep.with_name('case.json'))))
    subset=[]
    for folder in preliminary:
        src=HERE/folder
        for r in read(src/'summary.json')['cases']:
            assert (r['parent'],r['layout']) in indexed
            subset.append(dict(name=r['name'],motifs=r['motifs'],assignments=r['assignments'],
                               boundaries=r['boundaries'],positives=r['positives'],report=str(src.relative_to(HERE))+'/'+r['name']+'/report.json'))
    return dict(kappa='0.00387561167742',option_limit=24,min_changed=3,
        scope='All connected 3/4-bank motifs for each documented input, unchanged published price table, exterior ranking/truncation, frozen public boundaries and attached CPU histogram gate. Distinct stage graphs can have identical or overlapping candidate neighborhoods.',
        checkpoints=len(cases),distinct_canonical_words=len({r['parent'] for r in cases}),
        distinct_word_layout_pairs=len(indexed),distinct_layouts=len({r['layout'] for r in cases}),
        distinct_commits=len({r['commit'] for r in cases}),motifs=sum(r['motifs'] for r in cases),
        assignments=sum(r['assignments'] for r in cases),boundaries=sum(r['boundaries'] for r in cases),
        positives=sum(r['positives'] for r in cases),cases=cases,preliminary_top10000_subsets_not_added=subset,
        historical_input_pin_correction='The first basic probe completed #7756, then stopped before scoring #7781 when the public packed WORD differed from the final CLAIM digest. The file is the published pure-birth intermediate, pinned separately in CLAIM. The corrected complete run used its matching pure_birth_word and intermediate_layout. Preliminary prefixes are excluded from aggregate counts.')
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--folders',nargs='+',default=('probe-basic-pinned','probe-early','probe-earliest-all'))
    parser.add_argument('--preliminary',nargs='*',default=('probe-basic','probe-earliest-10k'))
    parser.add_argument('--out',type=Path,default=HERE/'historical-coverage.json')
    parser.add_argument('--compare',type=Path)
    a=parser.parse_args()
    obj=build(a.folders,a.preliminary)
    if a.compare:
        stored=read(a.compare)
        fields=('name','commit','parent','layout','motifs','assignments','boundaries','positives','census','boundary_stream_sha256')
        def index(cases):
            return {r['name']:{k:r[k] for k in fields} for r in cases}
        assert index(obj['cases'])==index(stored['cases'])
        obj['comparison_verified_fields']=list(fields)
    a.out.write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps({k:v for k,v in obj.items() if isinstance(v,int)}))
