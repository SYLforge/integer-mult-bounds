"""Presurvey worker count on both fixed plans before independent cold timings."""

import argparse
import json
from pathlib import Path
import statistics
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from cpu_score import FROZEN, score_selected
from bank_graph import read
from fast_search import boundary_record
from prepare_fast import select_motifs


def main(out):
    out.mkdir(parents=True, exist_ok=False)
    old = FROZEN.parents[1] / 'gpu-cpu-search-pilot-20261119/snapshot-172475c2/complex'
    newer = HERE.parent / 'public-787cddda/complex'
    plans = {}
    receipt = {'scope': 'Exploratory warm presurvey. Per-run clocks contain descriptor packing, thread-pool creation and shutdown, all rows and CPU boundary histograms. Excludes motif-plan preparation and Python startup.',
               'command': [sys.executable, '-I', '-B', str(Path(__file__).resolve()), *sys.argv[1:]],
               'runs': []}
    for name, folder, kappa in [('172475c2', old, '0.00387561167742'), ('787cddda', newer, '0.00387827242155')]:
        graph, layout = read(folder/'WORD.json.gz'), read(folder/'LAYOUT.json.gz')
        plans[name] = (graph, kappa, select_motifs(graph, layout, kappa, 10000, 24))
    for round_id, order in enumerate(([1, 4, 8, 12], [12, 8, 4, 1])):
        for index, threads in enumerate(order):
            names = list(plans)
            if (index + round_id) % 2:
                names.reverse()
            for name in names:
                graph, kappa, plan = plans[name]
                exact = []
                def consume(batch):
                    exact.extend(boundary_record(graph, plan, kappa, m, z, s) for m, z, s in batch)
                start = perf_counter()
                stats = score_selected(plan.selected, plan.old, plan.table, consume, threads=threads)
                elapsed = perf_counter() - start
                receipt['runs'].append(dict(input=name, threads=threads, round=round_id+1, wall_s=elapsed,
                                            assignments=stats['assignments_scored'], hits=exact,
                                            descriptor_s=stats['descriptor_packing_s'], pipeline_s=stats['pipeline_wall_s']))
                (out / 'threads.json').write_text(json.dumps(receipt, indent=2)+'\n')
                print(name, threads, round(elapsed, 4), flush=True)
    medians = {name: {n: statistics.median(v['wall_s'] for v in receipt['runs']
                                           if v['input'] == name and v['threads'] == n)
                      for n in (1, 4, 8, 12)} for name in plans}
    for name in plans:
        records = [json.dumps((v['assignments'], v['hits']), sort_keys=True) for v in receipt['runs'] if v['input'] == name]
        assert len(set(records)) == 1
    receipt['medians_s'] = medians
    receipt['best_individually'] = {name: min(values, key=values.get) for name, values in medians.items()}
    receipt['best_combined_by_sum_of_medians'] = min((1, 4, 8, 12), key=lambda n: sum(v[n] for v in medians.values()))
    (out/'threads.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(medians))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    main(parser.parse_args().out)
