"""Acquire the #7713 and #7726 deposited graph/interface pairs exported by their public successors."""
import concurrent.futures
import gzip
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent/'historical-inputs'
EXPORTS = [
    ('7726', '9e051455757d1cc86b822e52e42e1e1c98ead417', 'research/p104-parallel-bank-punctures',
     'ba59d5db17c40185c8608a734ced10135d8c041e432c3840e9034868781c31a2'),
    ('7713', '3ba9094c54b61f424d2f98cd2c6ca64c01baf9d3', 'research/p104-interleaved-helper-bases',
     '16e99893a2c669467ce74f214e8eb5150402f0267aaa8d67aad5d870aa4d5c18'),
]


def run(item):
    number, commit, sub, expected = item
    dest = ROOT/('export-'+number)
    dest.mkdir(parents=True,exist_ok=True)
    repo = 'CrocSwap/integer-mult-bounds'
    url = f'https://api.github.com/repos/{repo}/contents/{sub}/data?ref={commit}'
    headers = {'User-Agent':'public-graph-export-review'}
    with urlopen(Request(url,headers=headers),timeout=45) as response:
        tree = {i['name']:i for i in json.load(response)}
    report = {'source_pr':number,'export_commit':commit,'export_package':sub,'files':{}}
    for name in ('BASE-GRAPH.json.gz','BASE-INTERFACE.json'):
        loc = f'https://raw.githubusercontent.com/{repo}/{commit}/{sub}/data/{name}'
        with urlopen(Request(loc,headers=headers),timeout=45) as response:
            data = response.read()
        blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert blob == tree[name]['sha']
        raw = gzip.decompress(data) if name.endswith('.gz') else data
        value = json.loads(raw)
        canonical = hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        if name.endswith('.gz'):
            assert canonical == expected
            target = dest/'WORD.json.gz'
            packed = data
        else:
            assert 'live' in value and 'hosted' in value
            target = dest/'LAYOUT.json.gz'
            packed = gzip.compress(data,mtime=0)
        if target.exists():
            assert target.read_bytes() == packed
        else:
            target.write_bytes(packed)
        report['files'][name] = {'url':loc,'git_blob':blob,'canonical':canonical,
            'upstream_sha256':hashlib.sha256(data).hexdigest(),
            'local_file':target.name,'local_sha256':hashlib.sha256(packed).hexdigest()}
    (dest/'provenance.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(number,expected,flush=True)


if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        list(executor.map(run,EXPORTS))
