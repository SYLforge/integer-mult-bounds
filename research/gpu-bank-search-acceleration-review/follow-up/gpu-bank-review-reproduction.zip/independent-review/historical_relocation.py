"""Search public earlier input words with the unmodified benchmark relocation model."""
import argparse
import gzip
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from decimal import Decimal
from hashlib import sha256
from urllib.request import Request, urlopen

HERE=Path(__file__).resolve().parent
REVIEW=HERE/'review-633e1db0'
K='0.00387561167742'

def read(path):
    return json.loads(gzip.decompress(path.read_bytes()))

def canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(',',':')).encode()

def digest(obj):
    return sha256(canonical(obj)).hexdigest()

def prepare_public_inputs(cache,fetch):
    """Run the unchanged #7786 downloader after checking it and its lock by SHA."""
    local=HERE/'historical-bootstrap-787cddda'
    local.mkdir(exist_ok=True)
    pins={'prepare_sources.py':'c70c3be6e48717c6a9a561ef2294d23437a60d7dbcbbddc1305a6fc54001bb3d',
          'SOURCE-LOCK.json':'b46b919292e1a1907345056b6925f5f1400d45650e2f0f610779a07163bb64ee'}
    prefix='https://raw.githubusercontent.com/CrocSwap/integer-mult-bounds/787cdddaa7f32b05c44452b8c52a376b600b5348/research/p104-iterated-returns/'
    for name,pin in pins.items():
        path=local/name
        if path.exists():
            raw=path.read_bytes()
        elif fetch:
            with urlopen(Request(prefix+name,headers={'User-Agent':'p104-history-replay'}),timeout=60) as r:
                raw=r.read()
        else:
            raise FileNotFoundError(path)
        assert sha256(raw).hexdigest()==pin
        if not path.exists():
            path.write_bytes(raw)
    subprocess.run([sys.executable,'-I','-B',str(local/'prepare_sources.py'),str(cache),
                    *(['--fetch'] if fetch else [])],check=True)

def public_reader(cache):
    path=cache/'parent/complex/independent.py'
    assert sha256(path.read_bytes()).hexdigest()=='0b428bc6fac4dc6ec014114bf4119782553fbb58d92b2a632b51629f4abe563b'
    spec=importlib.util.spec_from_file_location('published_7781_reader',path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=mod
    spec.loader.exec_module(mod)
    return mod

def operator_check(reader,raw,layout):
    graph=reader.Graph.parse(raw)
    expected,_=reader.public_operator(graph,layout,[reader.span(f) for f in graph.frames])
    forward,_=reader.forward(graph)
    adjoint,_=reader.adjoint(graph)
    assert forward==expected and adjoint==reader.transpose(expected)
    return dict(all_forward_and_adjoint=True,addresses=graph.size,coefficients_each_direction=graph.size**2)

def check_case(case,folder,limit):
    from fast_search import run_round
    name,commit,g,layout,pin,lpin=case
    path=folder/name
    path.mkdir()
    assert digest(g)==pin and digest(layout)==lpin
    s=run_round(g,layout,K,motif_limit=limit,option_limit=24)
    (path/'report.json').write_text(json.dumps(s,indent=2)+'\n')
    rec=dict(name=name,commit=commit,parent=pin,layout=lpin,motifs=s['selected_motifs'],
             assignments=s['assignments_scored'],boundaries=len(s['boundary_records']),
             positives=len(s['positive_examples']),candidates=[])
    if rec['positives']:
        from bank_graph import component_graph,incidence,price_tables
        import numpy as np
        sys.path.insert(0,str(REVIEW/'multibank-latest-round-20261119'))
        import multibank_search as reference
        groups,_,old,edges=component_graph(g,layout)
        nb=incidence(old,edges)
        table=price_tables(g['frames'],K)[0][0]
        reader=public_reader(args.cache)
        rec['source_operator']=operator_check(reader,g,layout)
        # Persist most favorable distinct exact histogram/control first.
        unique=set()
        for r in s['positive_examples']:
            key=tuple(r['delta'])
            if key in unique:
                continue
            unique.add(key)
            score=int(reference.scores_cpu(np.array([r['charts']]),r['cluster'],old,nb,table)[0])
            assert score==r['score']
            child,_=reference.synthesize(g,groups,r['cluster'],r['charts'])
            delta,credit=reference.exact_credit(g,child,K)
            assert tuple([0]+[delta.get(i,0) for i in range(1,10)])==key
            assert credit>0 and abs(credit-Decimal(r['credit'])) < Decimal('1e-65')
            controls=operator_check(reader,child,layout)
            h=digest(child)
            (path/f'child-{h}.json.gz').write_bytes(gzip.compress(canonical(child),mtime=0))
            rec['candidates'].append(dict(**r,child=h,child_operator=controls))
            if len(unique)>=3:
                break
        (path/'WORD.json.gz').write_bytes(gzip.compress(canonical(g),mtime=0))
        (path/'LAYOUT.json.gz').write_bytes(gzip.compress(canonical(layout),mtime=0))
    (path/'case.json').write_text(json.dumps(rec,indent=2)+'\n')
    print(name,rec['assignments'],rec['boundaries'],rec['positives'],flush=True)
    return rec

def cases(which):
    if which=='exports':
        for label in ('7713','7726'):
            loc=HERE/f'historical-inputs/export-{label}'
            p=json.loads((loc/'provenance.json').read_text())
            g=read(loc/'WORD.json.gz'); l=read(loc/'LAYOUT.json.gz')
            yield f'pr{label}',p['export_commit'],g,l,p['files']['BASE-GRAPH.json.gz']['canonical'],p['files']['BASE-INTERFACE.json']['canonical']
        return
    base=args.cache
    engine=base/'source/research/p104-dual-supplier-lift/complex'
    manifest=json.loads((engine/'PARENT-SOURCES.json').read_text())
    pins={f['export']:f['content_sha256'] for f in manifest['files'] if 'export' in f}
    g=read(engine/'GRAPH.json.gz')
    l=read(engine/'LAYOUT.json.gz')
    if which=='basic':
        yield 'pr7756',manifest['commit'],g,l,pins['GRAPH.json.gz'],pins['LAYOUT.json.gz']
        pkg=base/'parent'
        claim=json.loads((pkg/'CLAIM.json').read_text())
        yield 'pr7781-pure-birth','913fb6febe28cc3ccad1c16de8e45b8bce0da063',read(pkg/'complex/WORD.json.gz'),read(pkg/'complex/LAYOUT.json.gz'),claim['pure_birth_word'],claim['intermediate_layout']
        return
    if which=='manifest':
        data=json.loads(args.manifest.read_text())
        for item in data:
            yield item['name'],item['commit'],read(Path(item['graph'])),read(Path(item['layout'])),item['word_sha256'],item['layout_sha256']
        return
    sys.path.insert(0,str(engine))
    import supplier
    frames=g['frames']
    net=supplier.Network(g['first_output'],g['initial'],g['final'],{k:(a,b) for k,a,b in g['moves']},
                         {k:supplier.coefficients(row) for k,row in g['forms']})
    for file in ('DELTA','STACK-DELTA'):
        path=engine/f'relays/{file}.json.gz'
        encoded=gzip.decompress(path.read_bytes())
        assert sha256(encoded).hexdigest()==manifest['relays']['files'][file+'.json']
        patch=json.loads(encoded)
        assert digest(g)==patch['parent_graph_sha256']
        net=supplier.restore_relays(net,patch)
        g=supplier.dump_graph(net,frames)
        yield 'pr7767-'+file.lower(),manifest['relays']['commit'],g,l,patch['joint_graph_sha256'],pins['LAYOUT.json.gz']
    net=supplier.rename_senders(net,{int(i):j for i,j in manifest['relays']['new_sender_names'].items()})
    g=supplier.dump_graph(net,frames)
    assert digest(g)==manifest['relays']['renamed_graph_sha256']
    stages=[supplier.read(engine/'BANK-EDITS.json'),supplier.read(engine/'PUBLIC-EDITS.json'),*supplier.read(engine/'BASIS-EDITS.json.gz')]
    commit='4f7c67ae387cc91580f469aeda4d508b372b9ec1'
    def layout_for(g):
        extra=len(g['initial'])-l['public']
        labels=l['source_labels']
        return dict(l,public=len(g['initial']),frames=g['frames'],source_labels=labels+list(range(max(labels)+1,max(labels)+1+extra)))
    for i,j in enumerate(stages):
        assert digest(g)==j['source_sha256']
        net=supplier.replay_events(net,j['events'])
        g=supplier.dump_graph(net,frames)
        ll=layout_for(g)
        yield f'pr7776-phase-{i:02}',commit,g,ll,j['output_sha256'],digest(ll)
    for i,edit in enumerate(supplier.read(engine/'JOINT-EDITS.json.gz')):
        assert digest(g)==edit['source']
        if 'events' in edit:
            frames=frames+edit.get('new_frames',[])
            net=supplier.replay_events(net,edit['events'])
        elif 'rotations' in edit:
            net=supplier.Network(net.first_output,net.initial,net.final,net.moves,supplier.rotate_all(net,edit['rotations']))
        else:
            net=supplier.apply_delta(net,edit)
        g=supplier.dump_graph(net,frames)
        ll=layout_for(g)
        yield f'pr7776-joint-{i:02}',commit,g,ll,edit['result'],digest(ll)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--which',choices=['basic','earlier','manifest','exports'],required=True)
    p.add_argument('--manifest',type=Path)
    p.add_argument('--cache',type=Path,default=HERE/'public-source-cache')
    p.add_argument('--fetch-sources',action='store_true',help='fetch the unchanged #7786 source-lock checker and its pinned files')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--limit',type=int,default=10000)
    p.add_argument('--max-cases',type=int,default=18)
    args=p.parse_args()
    sys.path.insert(0,str(REVIEW/'work/benchmark'))
    if args.fetch_sources:
        prepare_public_inputs(args.cache,True)
    args.out.mkdir(parents=True,exist_ok=False)
    results=[]
    summary=dict(command=[sys.executable,'-I','-B',str(Path(__file__).resolve()),*sys.argv[1:]],
        kappa=K,motif_limit=args.limit,option_limit=24,min_components_changed=3,published_checkpoints=True,cases=results)
    for case in cases(args.which):
        r=check_case(case,args.out,args.limit)
        results.append(r)
        (args.out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        if r['positives'] or len(results)>=args.max_cases:
            break

