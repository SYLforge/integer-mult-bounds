"""Independent small-graph / all-hit stress controls for the published optional scorer.

Run with the benchmark Python + NumPy, PyTorch, NVRTC, cuDriver, and cpu_score.
--out is a fresh directory. The untimed capacity test visits two full production
buffers. Its graph contains two disconnected chains and many distinct chart IDs.
"""
import argparse
from collections import Counter
from dataclasses import replace
from decimal import Decimal
from fractions import Fraction
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
KAPPA = "0.00387561167742"
READER_SHA = "0b428bc6fac4dc6ec014114bf4119782553fbb58d92b2a632b51629f4abe563b"


def need(ok, message):
    if not ok:
        raise ValueError(message)


def dump(path, data):
    with path.open("x", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def chain(copies=1, old=(2, 4, 6)):
    frames = [[1 << j for j in range(i)] for i in range(10)]
    route = [0, *old, 9]
    moves, forms = [], []
    for c in range(copies):
        start = 4*c
        for j, (s, t) in enumerate(zip(route[:-1], route[1:])):
            k = start+j
            moves.append([k,s,t])
            forms.append([k, [[~c if j == 0 else k-1, "1"]]])
        forms.append([10+c, [[start+3,"1"]]])
    graph = dict(frames=frames, initial=[0]*copies, final=[9]*copies,
                 first_output=10, moves=moves, forms=forms, schedule=[k for k,_ in forms])
    return graph, dict(live=[], hosted=dict(X2=[], Y2=[]))


def changed_charts(cluster, old, target):
    assignments = dict(zip((2,4,6),target))
    return [assignments[int(old[u])] for u in cluster]


def global_address(totals, ordinal):
    for m, total in enumerate(totals):
        if ordinal < total:
            return m, ordinal
        ordinal -= total
    raise ValueError("global ordinal out of range")


class Compare:
    def __init__(self, fused, audit, plan, expect_dense_score=None):
        self.fused, self.audit, self.plan = fused, audit, plan
        self.exact_score = expect_dense_score
        self.rows = 0
        self.near_rows = 0
        self.near_batches = []
        self.near = []
        self.score_counts = Counter()
        self.charts_hash, self.scores_hash = hashlib.sha256(), hashlib.sha256()
        self.totals = [math.prod(map(len,info[0])) for _,_,info in plan.selected]

    def dense_near(self, rows):
        # Every retained assignment in this geometric subdomain has the same
        # four rank differences and changes all three free banks, so all hit.
        n = len(rows)
        self.near_batches.append(n)
        start = self.near_rows
        pos = 0
        while pos < n:
            m, local = global_address(self.totals, start+pos)
            step = min(n-pos, self.totals[m]-local)
            for j in range(step):
                need(rows[pos+j] == (m,local+j,self.exact_score),
                     f"dense hit mismatch at global ordinal {start+pos+j}")
            pos += step
        self.near_rows += n

    def mixed_near(self, rows):
        self.near_batches.append(len(rows))
        self.near.extend(rows)
        self.near_rows += len(rows)

    def full(self, start, charts, scores):
        need(start == self.rows, "audit chunk ordering")
        need(charts.dtype == np.int32 and scores.dtype == np.int64, "audit types")
        need(charts.shape == (len(scores),4), "audit width")
        pos = 0
        while pos < len(scores):
            m, local = global_address(self.totals, start+pos)
            _, cluster, info = self.plan.selected[m]
            n = min(self.totals[m]-local, len(scores)-pos)
            cs = self.fused.s.assignments(info[0], local, local+n)
            direct = self.fused.s.scores_cpu(cs, cluster, self.plan.old,
                                             self.plan.neighbors, self.plan.table)
            legacy = self.audit.legacy_fused_scores(self.fused, info, cluster, self.plan.old,
                                                    self.plan.table, local, cs)
            a, b = charts[pos:pos+n], scores[pos:pos+n]
            need(np.array_equal(cs, a[:,:len(cluster)]) and np.all(a[:,len(cluster):]==0),
                 f"chart mismatch at {start+pos}")
            need(np.array_equal(legacy,direct) and np.array_equal(direct,b),
                 f"score mismatch at {start+pos}")
            if self.exact_score is not None:
                need(np.all(direct==self.exact_score), "dense tariff or legality")
            for val, count in zip(*np.unique(direct,return_counts=True)):
                self.score_counts[int(val)] += int(count)
            pos += n
        self.charts_hash.update(np.ascontiguousarray(charts,dtype="<i4").tobytes())
        self.scores_hash.update(np.ascontiguousarray(scores,dtype="<i8").tobytes())
        self.rows += len(scores)

    def result(self):
        need(self.rows == sum(self.totals), "incomplete row coverage")
        return dict(rows=self.rows, near_count=self.near_rows,
                    hit_counts_per_nonempty_batch=self.near_batches,
                    chart_digest=self.charts_hash.hexdigest(),
                    score_digest=self.scores_hash.hexdigest(),
                    score_counts=dict(sorted(self.score_counts.items())))


def run_backend(fn, fused, audit, plan, batch, dense=None):
    check = Compare(fused,audit,plan,dense)
    fn(plan.selected,plan.old,plan.table,
       check.mixed_near if dense is None else check.dense_near,
       on_audit=check.full,batch_size=batch)
    return check


def official_operator(source_cache, original, child):
    path = source_cache/"parent/complex/independent.py"
    need(hashlib.sha256(path.read_bytes()).hexdigest()==READER_SHA, "pinned reader hash")
    reader = load_module("fixture_pinned_reader", path)
    directory = source_cache/"source/research/shared-wire-split-composition/frozen"
    sys.path.insert(0, str(directory))
    import clifford_exact as producer
    import native_verify as checker
    receipts = {}
    for label,word in (("before",original),("after",child)):
        graph = reader.Graph.parse(word)
        spans = [reader.span(f) for f in graph.frames]
        paid, productive = reader.ranks(graph,set(),spans)
        expected = [{0:Fraction(1)}]
        need(reader.forward(graph)[0] == expected and reader.adjoint(graph)[0] == expected,
             "single-owner rational identity")
        path = []
        composed = ()
        for ident in graph.order:
            if ident not in graph.moves:
                continue
            s,t = graph.moves[ident]
            source = producer.canonical_frame(9,tuple(graph.frames[s]))
            target = producer.canonical_frame(9,tuple(graph.frames[t]))
            recipe, _ = producer.lower_child(source.adjoint().then(target))
            actual = checker.recipe(recipe)
            expected_pair = checker.adjoint(checker.frame(graph.frames[s],9)) + checker.frame(graph.frames[t],9)
            checker.equal(actual,expected_pair,"signed chart recipe")
            checker.equal(checker.adjoint(actual),checker.adjoint(expected_pair),"signed adjoint")
            need(recipe["rank"] == abs(len(graph.frames[s])-len(graph.frames[t])), "paid physical rank")
            path.append(dict(charts=[s,t],rank=recipe["rank"]))
            composed += tuple(actual)
        reference = checker.adjoint(checker.frame(graph.frames[graph.initial[0]],9)) + checker.frame(graph.frames[graph.final[0]],9)
        checker.equal(composed,reference,"physical endpoint map (signed tableau and phase)")
        checker.equal(checker.adjoint(composed),checker.adjoint(reference),"physical adjoint")
        receipts[label]=dict(checked_routes=path, paid_histogram=dict(sorted(paid.items())),
                             productive_histogram=dict(sorted(productive.items())),
                             forward_rational=[["1"]], adjoint_rational=[["1"]],
                             physical_endpoints=[graph.initial[0],graph.final[0]])
    return receipts


def alt_bases(dim, limit):
    # Enumerate distinct ordered independent bases of the fixed coordinate
    # space F2^dim. This yields distinct chart IDs, including equal-span charts.
    def visit(prefix, span):
        if len(prefix)==dim:
            yield list(prefix)
            return
        for x in range(1,1<<dim):
            if x not in span:
                yield from visit(prefix+(x,), span | {s^x for s in span})
    standard = [1<<j for j in range(dim)]
    return list(itertools.islice((f for f in visit((),{0}) if f!=standard),limit))


def restrict(plan, choices):
    selected=[]
    for upper, cluster, info in plan.selected:
        opts, prices, weights, baseline, edgecount, upper2=info
        new_opts, new_prices=[],[]
        for axis,u in enumerate(cluster):
            allowed = set(choices[int(plan.old[u])])
            take = [i for i,chart in enumerate(opts[axis]) if int(chart) in allowed]
            need(len(take)==len(allowed),"expected legal options in descriptor")
            new_opts.append(opts[axis][take])
            new_prices.append(prices[axis][take])
        selected.append((upper,cluster,(new_opts,new_prices,weights,baseline,edgecount,upper2)))
    return replace(plan, selected=selected)


def subset_plan_test(mod, fused, graph, layout, size):
    variants = {}
    for before, after in ((2,3),(4,5),(6,8)):
        bases = alt_bases(after,size)
        need(len(bases)==size, "missing independent bases")
        begin = len(graph["frames"])
        graph["frames"].extend(bases)
        variants[before] = range(begin,begin+len(bases))
    full = mod.select_motifs(graph,layout,KAPPA,10000,0)
    plan = restrict(full,variants)
    need(len(plan.selected)==2, "two eligible disconnected chain motifs")
    _,cluster,info = plan.selected[0]
    example = fused.s.assignments(info[0],0,1)
    score = int(fused.s.scores_cpu(example,cluster,plan.old,plan.neighbors,plan.table)[0])
    need(score>0, "dense domain requires strictly positive score")
    return plan,score


def check_small(args, modules, out):
    audit,fast,prepmod,gpu,cpu,fused=modules
    graph,layout=chain()
    dump(out/"toy-word.json",graph)
    dump(out/"toy-layout.json",layout)
    legacy, survivors, census,old,neighbors,table = audit.legacy_selection(fused,graph,layout,KAPPA,10000,24)
    plan=prepmod.select_motifs(graph,layout,KAPPA,10000,24)
    ph=audit.check_plans(legacy,plan.selected)
    need(survivors==1 and len(legacy)==1 and np.array_equal(table,plan.table),"chain selection")
    _,cluster,info=legacy[0]
    charts=fused.s.assignments(info[0],0,math.prod(map(len,info[0])))
    score=fused.s.scores_cpu(charts,cluster,old,neighbors,table)
    near_list=[(0,int(j),int(score[j])) for j in np.flatnonzero(score>=-info[4]-2)]
    target=changed_charts(cluster,old,(1,2,3))
    idx=int(np.flatnonzero(np.all(charts==target,axis=1))[0])
    check_target=(0,idx,int(score[idx]))
    records=[]
    for m,j,s in near_list:
        record=fast.boundary_record(graph,plan,KAPPA,m,j,s)
        ref=audit.legacy_boundary(fused,graph,old,neighbors,KAPPA,m,j,s,cluster,charts[j].tolist(),info[4])
        for key in record.keys()-{"credit"}:
            need(record[key]==ref[key], f"legacy singleton exact decision {j}/{key}")
        need(Decimal(record["credit"])==Decimal(ref["credit"]), "exact credit disagreement")
        records.append(record)
    need(check_target in near_list,"nominated gain was screened")
    target_record=next(r for r in records if r["local_ordinal"]==idx)
    need(target_record["positive"] and [n for n in target_record["delta"]]==[0,-3,3,1,0,0,-1,0,0,0],
         "nominated exact tariff credit")
    grouped,_=fused.exact_patterns(graph,cluster,old,neighbors,charts[[j for _,j,_ in near_list]],{},KAPPA)
    classes={tuple(r["delta"]) for r in records if r["positive"]}
    need(classes=={tuple(x[3]) for x in grouped},"grouped legacy histogram classes")
    checks={}
    for name,fn in (("fast_cpu",cpu.score_selected),("gpu",gpu.score_selected)):
        test=run_backend(fn,fused,audit,plan,37)
        need(test.near==near_list, f"{name} production boundary order or membership")
        checks[name]=test.result()
    need(checks["fast_cpu"]==checks["gpu"], "all untrimmed chain rows")
    child,collapsed=fused.s.synthesize(graph,plan.groups,cluster,target)
    need(not collapsed and child["moves"]==[[0,0,1],[1,1,2],[2,2,3],[3,3,9]],
         "expected uncancelled literal transfers")
    dump(out/"toy-child.json",child)
    verified=official_operator(args.source_cache,graph,child)
    delta,gain = fused.s.exact_credit(graph,child,KAPPA)
    need(abs(Decimal(target_record["credit"])-gain)<Decimal("1e-70"), "full-word tariff")
    reverse_p=prepmod.select_motifs(child,layout,KAPPA,10000,24)
    _,reverse_cluster,rinfo=reverse_p.selected[0]
    reverse_charts=fused.s.assignments(rinfo[0],0,math.prod(map(len,rinfo[0])))
    reverse_target=[{1:2,2:4,3:6}[int(reverse_p.old[u])] for u in reverse_cluster]
    rev=int(np.flatnonzero(np.all(reverse_charts==reverse_target,axis=1))[0])
    rs=int(fused.s.scores_cpu(reverse_charts[rev:rev+1],reverse_cluster,reverse_p.old,reverse_p.neighbors,reverse_p.table)[0])
    revrec=fast.boundary_record(child,reverse_p,KAPPA,0,rev,rs)
    need(rs< -rinfo[4]-2 and Decimal(revrec["credit"])<0 and not revrec["positive"],
         "reverse is screened with a strictly adverse exact tariff")
    # A tiny positive exponent shift keeps the reverse's rounded integer score at
    # zero while its true credit is strictly negative and well above 90-digit noise.
    tiny="1e-20"
    weak=prepmod.select_motifs(child,layout,tiny,10000,24)
    _,wcluster,winfo=weak.selected[0]
    wcharts=fused.s.assignments(winfo[0],0,math.prod(map(len,winfo[0])))
    wj=int(np.flatnonzero(np.all(wcharts==reverse_target,axis=1))[0])
    weak_near=[]
    for name,fn in (("fast_cpu",cpu.score_selected),("gpu",gpu.score_selected)):
        test=run_backend(fn,fused,audit,weak,59)
        need((0,wj,0) in test.near, "near-zero negative was incorrectly prefiltered")
        weak_near.append(test.near)
    need(weak_near[0]==weak_near[1], "tiny-kappa near equality")
    neg=fast.boundary_record(child,weak,tiny,0,wj,0)
    nref=audit.legacy_boundary(fused,child,weak.old,weak.neighbors,tiny,0,wj,0,wcluster,reverse_target,winfo[4])
    need(Decimal(neg["credit"])==Decimal(nref["credit"])<0 and not neg["positive"],"tiny-kappa exact reject")
    return dict(scope="Synthetic single-owner gain control, not a public P104 multiplier or kappa result",
                kappa=KAPPA, plan_sha256=ph, motifs=1, legacy_positive_histogram_classes=len(classes),
                exact_positive_assignments=sum(r["positive"] for r in records), exact_zero_assignments=sum(Decimal(r["credit"])==0 for r in records),
                source_hash=fast.canonical_hash(graph),child_hash=fast.canonical_hash(child),
                nominated=target_record, whole_word_credit=str(gain), paid_delta=dict(delta),
                reverse_nomination=revrec, near_zero_negative=dict(kappa=tiny, record=neg),
                operator=verified, note="Legacy fused report represents each positive histogram by its first row within a motif chunk; all positive rows and histogram classes were checked separately.",
                audit=checks)


def threshold_control(modules):
    # Exercise the exact integer comparison with synthetic shifts: these three
    # baseline values test one-unit boundaries; they are not graph-cost claims.
    audit,fast,prepmod,gpu,cpu,fused=modules
    graph,layout=chain()
    plan=prepmod.select_motifs(graph,layout,KAPPA,10000,24)
    one=restrict(plan,{2:[1],4:[2],6:[3]})
    upper,cluster,info=one.selected[0]
    cs=fused.s.assignments(info[0],0,1)
    score=int(fused.s.scores_cpu(cs,cluster,plan.old,plan.neighbors,plan.table)[0])
    threshold=-info[4]-2
    selected=[]
    refs=[]
    for desired in (threshold-1,threshold,threshold+1):
        variant=(*info[:3],info[3]+score-desired,*info[4:])
        selected.append((upper,cluster,variant))
        refs.extend(audit.legacy_fused_scores(fused,variant,cluster,plan.old,plan.table,0,cs).tolist())
    need(refs==[threshold-1,threshold,threshold+1],"three integer boundary scores")
    results={}
    for name,fn in (("fast_cpu",cpu.score_selected),("gpu",gpu.score_selected)):
        rows,all_scores=[],[]
        def compare(start, charts, scores):
            need(start==len(all_scores) and np.all(charts[:,:3]==cs)
                 and np.all(charts[:,3]==0),"threshold rows/order")
            all_scores.extend(scores.tolist())
        fn(selected,plan.old,plan.table,rows.extend,on_audit=compare,batch_size=2)
        need(all_scores==refs and rows==[(1,0,threshold),(2,0,threshold+1)],
             "strict below / inclusive equality / above")
        results[name]=dict(all_scores=all_scores, near=rows)
    return dict(scope="Controlled integer comparator via synthetic baseline shifts; no physical tariff claim",
                affected_edges=info[4], cutoff=threshold, unshifted_score=score,
                original_cpu_scores=refs, paths=results)


def check_capacity(modules):
    audit,fast,prepmod,gpu,cpu,fused=modules
    result={}
    for size,batch,label in ((81,524288,"full_default"),(1,1,"one_row_slots"),(2,3,"small_partial")):
        g,layout=chain(copies=2)
        plan,score=subset_plan_test(prepmod,fused,g,layout,size)
        expected=2*size**3
        pattern=[batch]*(expected//batch)+([expected%batch] if expected%batch else [])
        case={}
        for name,fn in (("fast_cpu",cpu.score_selected),("gpu",gpu.score_selected)):
            check=run_backend(fn,fused,audit,plan,batch,dense=score)
            case[name]=check.result()
            need(check.near_rows==expected and check.near_batches==pattern,
                 f"incomplete all-hit chunks: {name} {label}")
        need(case["fast_cpu"]==case["gpu"],"full buffers differ across backends")
        need(len(set(plan.selected[0][1]) & set(plan.selected[1][1]))==0,
             "lot requires different free components")
        # Compute exact decision at all batch and motif seams; every row has the
        # same rank signature (both copies 2,4,6 -> 3,5,8), so this covers all classes.
        seams={0,expected-1,size**3-1,size**3}
        for n in range(batch,expected,batch):
            seams.update((n-1,n))
        samples=[]
        for n in sorted(seams):
            m,j=global_address([size**3]*2,n)
            rec=fast.boundary_record(g,plan,KAPPA,m,j,score)
            need(rec["positive"],"expected positive geometric control")
            samples.append(dict(global_ordinal=n,**rec))
        result[label]=dict(batch_size=batch,chart_ids_per_axis=size,expected=expected,
                           motifs=[list(row[1]) for row in plan.selected],
                           hit_batches=pattern,compared_all_global_and_local_ordinals=True,
                           exact_seam_records=samples,audit=case)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--review-package",type=Path,default=HERE/"review-633e1db0")
    p.add_argument("--source-cache",type=Path,default=HERE.parent/"public-source-cache")
    p.add_argument("--out",required=True,type=Path)
    p.add_argument("--part",choices=("small","capacity","both"),default="both")
    a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=False)
    bench=a.review_package.resolve()/"work/benchmark"
    sys.path[:0]=[str(HERE),str(bench)]
    import audit,fast_search,prepare_fast,gpu_score,cpu_score
    fused=audit.load_legacy(a.review_package.resolve()/"multibank-latest-round-20261119")
    packages=(audit,fast_search,prepare_fast,gpu_score,cpu_score,fused)
    checker_dir=a.source_cache/"source/research/shared-wire-split-composition/frozen"
    out=dict(command=[sys.executable,"-I","-B",str(Path(__file__).resolve()),*sys.argv[1:]],
             reviewed_commit="633e1db0d750299a29075d65d66607bcd73b4518",
             gpu_sha256=hashlib.sha256(Path(gpu_score.__file__).read_bytes()).hexdigest(),
             kernel_sha256=hashlib.sha256(Path(gpu_score.__file__).with_suffix(".cu").read_bytes()).hexdigest(),
             cpu_sha256=hashlib.sha256(Path(cpu_score.__file__).read_bytes()).hexdigest(),
             fixture_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             public_rational_reader_sha256=READER_SHA,
             public_chart_source_hashes={name:hashlib.sha256((checker_dir/name).read_bytes()).hexdigest()
                                         for name in ("clifford_exact.py","native_verify.py")})
    if a.part in ("small","both"):
        out["positive_fallback"]=check_small(a,packages,a.out)
    if a.part in ("capacity","both"):
        out["one_unit_threshold"]=threshold_control(packages)
        out["all_hit_controls"]=check_capacity(packages)
    out["status"]="PASS"
    dump(a.out/"fixture-report.json",out)
    print(json.dumps({k:(v if k=="status" else "complete") for k,v in out.items()
                      if k in ("status","positive_fallback","all_hit_controls")}))


if __name__=="__main__":
    main()
