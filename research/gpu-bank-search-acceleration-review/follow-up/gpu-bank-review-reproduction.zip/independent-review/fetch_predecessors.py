"""Materialize candidate positive controls from immutable published #7786 checkpoints."""
import gzip
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent/'historical-inputs'
REPO = 'CrocSwap/integer-mult-bounds'
BASE = 'research/p104-iterated-returns'
COMMITS = (
    'ad6880933898e2fc4f05e4f9eb43496bf7bd2621',
    '0a0b8f9872407a969d367d20ba2f3ea468f367df',
    'ebaad1e85b5d6a1847c5cd464a185a275d771329',
    'c68e9c9e5e3ad9b52916f7e3ac490194760b910a',
    'c6d7a3b548484dab6771fe2a1a8ba65c5cab454c',
    'ff6f1d8ab3fafb71ea12ccd943013d058c0f5847',
    '14f61fbd8b8fde33f3ed2add20f9829f4ac884cf',
    '75d4f4105b8f4e4017abb00a665aa72970831e4e',
    '172475c2ca321d3496fda7a2a71478ada5acb948',
)


def fetch(args):
    commit, name = args
    url = f'https://raw.githubusercontent.com/{REPO}/{commit}/{BASE}/{name}'
    path = ROOT/commit[:8]/name
    if path.exists():
        data = path.read_bytes()
    else:
        try:
            with urlopen(Request(url, headers={'User-Agent':'public-checkpoint-replay'}), timeout=45) as resp:
                data = resp.read()
        except HTTPError as exc:
            if exc.code == 404:
                return commit, name, {'available': False}
            raise
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    item = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
            'git_blob': hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
    if name.endswith('.gz'):
        value = json.loads(gzip.decompress(data))
        item['canonical'] = hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',',':')).encode()).hexdigest()
    return commit, name, item


def main():
    records = {sha: {'commit':sha, 'files':{}} for sha in COMMITS}
    jobs = [(sha, name) for sha in COMMITS for name in ('CLAIM.json','complex/WORD.json.gz','complex/LAYOUT.json.gz','NOTICE','LICENSE')]
    with ThreadPoolExecutor(max_workers=6) as executor:
        for sha, name, item in executor.map(fetch, jobs):
            records[sha]['files'][name] = item
    for sha, entry in records.items():
        claim_path = ROOT/sha[:8]/'CLAIM.json'
        if claim_path.is_file():
            claim = json.loads(claim_path.read_bytes())
            for key in ('finite_lower','complex_raw','complex_word','layout','ordinary_binary'):
                entry[key] = claim.get(key)
        entry['canonical_matches_claim'] = all(entry['files'][p].get('canonical') == entry.get(key) and entry.get(key)
                                              for p,key in [('complex/WORD.json.gz','complex_word'),('complex/LAYOUT.json.gz','layout')])
    report = {'repository':REPO, 'subdirectory':BASE, 'checkpoints':list(records.values())}
    (ROOT/'manifest.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    for v in records.values():
        print(v['commit'][:8],v.get('finite_lower'),v['canonical_matches_claim'],v['files']['complex/WORD.json.gz'].get('canonical','')[:9])


if __name__ == '__main__':
    main()
