"""Summarize the two matched timing experiments and the pinned correctness receipts."""
import argparse
import json
from pathlib import Path
from statistics import median


def read(path):
    return json.loads(path.read_bytes())


def summarize(timing):
    data = read(timing / "timing.json")
    result = {}
    for pin, row in data["results"].items():
        runs = [x for x in data["runs"] if x["input"] == pin]
        assert len(runs) == 18 and all(x["exit_code"] == 0 for x in runs)
        paired = []
        for start in range(0, len(runs), 3):
            group = {r["backend"]:r["process_wall_s"] for r in runs[start:start+3]}
            assert len(group)==3
            paired.append(group["fast_cpu"] - group["fast_gpu"])
        phases = {}
        for engine in ("fast_cpu","fast_gpu"):
            records = [read(timing / x["report"]) for x in runs if x["backend"]==engine]
            info = [r["cpu" if engine == "fast_cpu" else "gpu"] for r in records]
            phases[engine] = {"common_prepare_s":median(r["common_preparation_s"] for r in records),
                              "descriptor_pack_s":median(r["descriptor_packing_s"] for r in info),
                              "scorer_s":median(r["scorer_wall_s"] for r in info)}
            if engine == "fast_cpu":
                assert all(i["threads"]==data["cpu_threads_requested"] for i in info)
            else:
                assert all(i["compilation"].find("-no-cache") >= 0 for i in info)
        result[pin] = dict(**row, phased_medians_s=phases,
                           paired_fast_cpu_minus_gpu_s=paired,
                           blocks_gpu_faster=sum(x>0 for x in paired),
                           blocks_cpu_faster=sum(x<0 for x in paired))
    return dict(threads=data["cpu_threads_requested"], fresh_processes=len(data["runs"]), inputs=result)


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--timing", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    opts=p.parse_args()
    summary=summarize(opts.timing)
    opts.out.write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(summary,indent=2))

