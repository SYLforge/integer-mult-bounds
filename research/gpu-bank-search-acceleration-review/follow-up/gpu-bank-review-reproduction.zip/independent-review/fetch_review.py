"""Recover the 16 public review files by tree and blob identity, preserving original bytes."""

import concurrent.futures
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen


HERE = Path(__file__).resolve().parent
REPO = 'SYLforge/integer-mult-bounds'
COMMIT = '633e1db0d750299a29075d65d66607bcd73b4518'
BRANCH = 'review/gpu-search-acceleration'
DIRECTORY = 'research/gpu-bank-search-acceleration-review'
ROOT = HERE / 'review-633e1db0'


def read_url(url):
    with urlopen(Request(url, headers={'User-Agent': 'independent-public-review'}), timeout=50) as response:
        return response.read()


def github(path):
    return json.loads(read_url(f'https://api.github.com/repos/{REPO}/git/{path}'))


def store(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        path.write_bytes(data)


def fetch(entry):
    relative = entry['path']
    url = f'https://raw.githubusercontent.com/{REPO}/{COMMIT}/{DIRECTORY}/{relative}'
    path = ROOT / relative
    assert path.resolve().is_relative_to(ROOT)
    data = path.read_bytes() if path.is_file() else read_url(url)
    assert len(data) == entry['size']
    oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert oid == entry['sha']
    store(path, data)
    return dict(path=relative, git_blob=oid, sha256=hashlib.sha256(data).hexdigest(), size=len(data))


def main():
    commit = github('commits/' + COMMIT)
    assert commit['sha'] == COMMIT
    ref = github('ref/heads/' + BRANCH)['object']['sha']
    root_oid = commit['tree']['sha']
    tree_oid = root_oid
    rootfiles = None
    for directory in DIRECTORY.split('/'):
        tree = github('trees/' + tree_oid)
        assert not tree['truncated'] and tree['sha'] == tree_oid
        if rootfiles is None:
            rootfiles = tree['tree']
        tree_oid = next(i['sha'] for i in tree['tree'] if i['path'] == directory and i['type'] == 'tree')
    tree = github('trees/' + tree_oid + '?recursive=1')
    assert not tree['truncated'] and tree['sha'] == tree_oid
    entries = [i for i in tree['tree'] if i['type'] == 'blob']
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        files = list(executor.map(fetch, entries))
    notices = []
    for item in rootfiles:
        if item['path'] not in {'LICENSE', 'NOTICE'}:
            continue
        data = read_url(f'https://raw.githubusercontent.com/{REPO}/{COMMIT}/' + item['path'])
        oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert oid == item['sha']
        store(HERE/'review-licenses'/item['path'], data)
        notices.append({'path': item['path'], 'git_blob': oid, 'sha256': hashlib.sha256(data).hexdigest()})
    record = {'repository': REPO, 'commit': COMMIT, 'branch': BRANCH, 'branch_sha_at_fetch': ref,
              'tree': root_oid, 'parent': [i['sha'] for i in commit['parents']], 'subdirectory': DIRECTORY,
              'subtree': tree_oid, 'root_license_files': notices, 'files': files}
    (HERE/'review-provenance.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(f'Verified {len(files)} files at {COMMIT}, subtree {tree_oid}.')


if __name__ == '__main__':
    main()
