"""Elementwise two-device audit using the published CPU graph oracle at two pins."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
from queue import Empty, Full, Queue
import subprocess
import sys
from threading import Event

import numpy as np


HERE = Path(__file__).resolve().parent
REVIEW = HERE / 'review-633e1db0'
BENCHMARK = REVIEW / 'work' / 'benchmark'
LEGACY = REVIEW / 'multibank-latest-round-20261119'
REVIEW_COMMIT = '633e1db0d750299a29075d65d66607bcd73b4518'
PINS = {
    '172475c2': (
        '172475c2ca321d3496fda7a2a71478ada5acb948', '0.00387561167742',
        REVIEW / 'gpu-cpu-search-pilot-20261119' / 'snapshot-172475c2' / 'complex',
        '341c49e9b9d6e8742f948cba2407f7ad67164f87f4191c21319730cfc8b419d3',
        '5bd55b71fd1757a2c907bdc2a32f69e29b38f960fa95b67780842502888e2364'),
    '787cddda': (
        '787cdddaa7f32b05c44452b8c52a376b600b5348', '0.00387827242155',
        HERE.parent / 'public-787cddda' / 'complex',
        '46ea629a4698a96df7664d9f36019cbd181e80985b512edff2bef0e0ca981a52',
        '9ef2bcefc0f77ad98eb33da88f4f488d102d1529ab6b6004b298d182bd52b3ec')}

sys.dont_write_bytecode = True
sys.path[:0] = [str(BENCHMARK), str(HERE)]


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def review_manifest():
    provenance = json.loads((HERE / 'review-provenance.json').read_text(encoding='utf-8'))
    need(provenance['commit'] == REVIEW_COMMIT, 'unexpected public review commit')
    for item in provenance['files']:
        path = (REVIEW / item['path']).resolve()
        need(path.is_relative_to(REVIEW) and sha(path) == item['sha256'],
             f'public review file changed: {item["path"]}')
    return provenance


class CpuRows:
    """Deliver owned CPU batches to the GPU audit callback with bounded memory."""

    def __init__(self):
        self.rows = Queue(maxsize=1)
        self.stop = Event()
        self.batch = None
        self.offset = 0
        self.compared = 0

    def publish(self, start, charts, scores):
        # The producer may overwrite the original views as soon as we return.
        item = (int(start), np.array(charts, copy=True), np.array(scores, copy=True))
        while not self.stop.is_set():
            try:
                self.rows.put(item, timeout=0.1)
                return
            except Full:
                continue
        raise RuntimeError('GPU consumer stopped after an audit failure')

    def compare(self, start, charts, scores, producer):
        need(self.compared == start, f'GPU stream skipped global row {self.compared}')
        cursor = 0
        while cursor < len(scores):
            if self.batch is None:
                try:
                    self.batch = self.rows.get(timeout=0.1)
                except Empty:
                    if producer.done() and self.rows.empty():
                        producer.result()
                        raise ValueError('CPU stream ended before the GPU stream')
                    continue
                pos, cpu_charts, cpu_scores = self.batch
                need(pos == self.compared, f'CPU stream skipped global row {self.compared}')
                need(cpu_scores.dtype == np.int64 and cpu_scores.ndim == 1 and len(cpu_scores) > 0 and
                     cpu_charts.dtype == np.int32 and cpu_charts.shape == (len(cpu_scores), 4),
                     'CPU stream audit schema mismatch')
                self.offset = 0
            _, cpu_charts, cpu_scores = self.batch
            size = min(len(cpu_scores) - self.offset, len(scores) - cursor)
            c = slice(self.offset, self.offset + size)
            g = slice(cursor, cursor + size)
            chart_equal = np.array_equal(cpu_charts[c], charts[g])
            score_equal = np.array_equal(cpu_scores[c], scores[g])
            if not (chart_equal and score_equal):
                idx = np.flatnonzero((cpu_scores[c] != scores[g]) |
                                     np.any(cpu_charts[c] != charts[g], axis=1))[0]
                raise ValueError(f'CPU/GPU difference at global row {self.compared + idx}: '
                                 f'CPU {cpu_charts[self.offset+idx].tolist()}/{cpu_scores[self.offset+idx]}, '
                                 f'GPU {charts[cursor+idx].tolist()}/{scores[cursor+idx]}')
            self.offset += size
            self.compared += size
            cursor += size
            if self.offset == len(cpu_scores):
                self.batch = None


def normalized(records):
    return [dict(r, credit=Decimal(r['credit'])) for r in records]


def check_packed(gpu, plan, selected, old, table):
    arrays, total = gpu._pack(plan.selected, plan.old, plan.table)
    prefix, meta, baseline, options, prices, tariff = arrays
    names = ['prefix', 'meta', 'baseline', 'chart_options', 'exterior_values', 'tariff']
    hashes = {name: hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
              for name, a in zip(names, arrays, strict=True)}
    need(np.array_equal(tariff, table), 'packed tariff differs')
    count = 0
    for i, (_, cluster, info) in enumerate(selected):
        opts, external, internal, old_value, edgecount, _ = info
        need(int(prefix[i]) == count and int(baseline[i]) == old_value, f'packed prefix or baseline at {i}')
        axes = meta[i]
        for j in range(4):
            real = j < len(cluster)
            ref_options = opts[j] if real else [0]
            ref_prices = external[j] if real else [0]
            radix, offset = int(axes[j]), int(axes[4+j])
            section = slice(offset, offset + radix)
            need(radix == len(ref_options) and offset >= 0 and
                 int(axes[8+j]) == (old[cluster[j]] if real else 0) and
                 np.array_equal(options[section], ref_options) and np.array_equal(prices[section], ref_prices),
                 f'packed chart IDs, radices, old IDs or exterior prices at {i}/{j}')
        pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
        need(list(axes[12:18]) == [internal.get(p, 0) for p in pairs] and axes[18] == edgecount,
             f'packed pair weights or boundary tolerance at {i}')
        count += math.prod(map(len, opts))
    need(count == total == int(prefix[-1]), 'packed total differs')
    return hashes


def run(args):
    manifest = review_manifest()
    import audit
    import cpu_score
    import fast_search
    import gpu_score
    from prepare_fast import select_motifs

    for module in (audit, fast_search, gpu_score):
        need(Path(module.__file__).resolve().parent == BENCHMARK, f'unpinned {module.__name__} module')
    need(Path(cpu_score.__file__).resolve().parent == HERE, 'unexpected CPU scorer')
    pin, kappa, default_inputs, graph_hash, layout_hash = PINS[args.pin]
    inputs = args.input_dir.resolve() if args.input_dir else default_inputs
    graph_path, layout_path = inputs / 'WORD.json.gz', inputs / 'LAYOUT.json.gz'
    need(sha(graph_path) == graph_hash and sha(layout_path) == layout_hash, 'input checksum mismatch')
    legacy = audit.load_legacy(LEGACY)
    g, layout = legacy.read(graph_path), legacy.read(layout_path)
    selected, survivors, census, old, neighbors, table = audit.legacy_selection(
        legacy, g, layout, kappa, args.motifs, args.options)
    plan = select_motifs(g, layout, kappa, args.motifs, args.options)
    need(census == plan.census and survivors == plan.nonexcluded, 'selected motif census mismatch')
    need(np.array_equal(old, plan.old) and np.array_equal(table, plan.table), 'initial chart/tariff mismatch')
    plan_hash = audit.check_plans(selected, plan.selected)
    packed_hashes = check_packed(gpu_score, plan, selected, old, table)
    oracle = audit.OrderedRows(legacy, selected, g, old, neighbors, table, kappa)
    stream = CpuRows()
    cpu_near, gpu_near = [], []

    def near(records):
        def collect(rows):
            for i, ordinal, score in rows:
                records.append(fast_search.boundary_record(g, plan, kappa, int(i), int(ordinal), int(score)))
        return collect

    common = (plan.selected, plan.old, plan.table)
    with ThreadPoolExecutor(max_workers=1) as executor:
        producer = executor.submit(cpu_score.score_selected, *common, near(cpu_near), on_audit=stream.publish,
                                   batch_size=args.batch, threads=args.threads)

        def compare(start, charts, scores):
            stream.compare(start, charts, scores, producer)
            oracle.compare(start, charts, scores)

        try:
            gpu_stats = gpu_score.score_selected(*common, near(gpu_near), on_audit=compare, batch_size=args.batch)
            # Stop the producer if it sent surplus data; a successful producer
            # has already delivered its final comparison buffer at this point.
            need(stream.batch is None and stream.rows.empty(), 'CPU emitted extra candidate rows')
        finally:
            stream.stop.set()
        cpu_stats = producer.result()
        need(stream.rows.empty(), 'CPU emitted rows after the GPU finished')

    rows = sum(oracle.totals)
    need(stream.compared == oracle.cursor == cpu_stats['assignments_scored'] == gpu_stats['assignments_scored'] == rows
         and oracle.motif == len(selected) and oracle.offset == 0, 'incomplete Cartesian coverage')
    need(normalized(cpu_near) == normalized(gpu_near) == normalized(oracle.near),
         'near coordinates, integer histogram, score, credit or decision differ')
    result = dict(status='PASS', review_commit=REVIEW_COMMIT, review_tree=manifest['subtree'],
                  input_commit=pin, kappa=kappa, chart_limit=args.options, motif_limit=args.motifs,
                  input_sha256={'graph': graph_hash, 'layout': layout_hash},
                  canonical_graph_sha256=fast_search.canonical_hash(g),
                  command=subprocess.list2cmdline([sys.executable, '-I', '-B', str(Path(__file__).resolve()),
                                                   *sys.argv[1:]]),
                  motifs=len(selected), motif_census=dict(census), nonexcluded_motifs=survivors,
                  ordered_selected_motif_option_weight_sha256=plan_hash,
                  compact_arrays_compared_to_original=True, compact_array_sha256=packed_hashes,
                  all_rows_compared_elementwise=rows,
                  ordered_charts_sha256_le_int32_4_columns=oracle.charts_sha.hexdigest(),
                  ordered_scores_sha256_le_int64=oracle.scores_sha.hexdigest(),
                  comparisons=['fast CPU vs actual CUDA chart IDs and int64 scores',
                               'both vs original mixed-radix chart IDs and CPU graph-incidence score',
                               'both vs original fused integer CPU score',
                               'both compacted near streams and exact decisions vs original exact_patterns and scalar histogram'],
                  boundary_records=oracle.near, positives=sum(r['positive'] for r in oracle.near),
                  gpu_device=gpu_stats['device'], cpu_threads=args.threads, batch_size=args.batch,
                  cpu_scorer_sha256=sha(Path(cpu_score.__file__)), cpu_engine=cpu_stats['backend'],
                  numpy_version=np.__version__, audit_script_sha256=sha(Path(__file__)),
                  benchmark_timing=False)
    if args.pin == '172475c2' and args.motifs == 10000 and args.options == 24:
        expected = json.loads((REVIEW / 'evidence' / 'audit-final.json').read_text())
        need(rows == expected['rows_compared_elementwise'] and
             plan_hash == expected['plan_sha256'] and
             normalized(oracle.near) == normalized(expected['boundary_records']) and
             result['ordered_scores_sha256_le_int64'] == expected['ordered_scores_sha256_le_int64'] and
             result['ordered_charts_sha256_le_int32_4_columns'] == expected['ordered_charts_sha256_le_int32_4_columns'],
             'pinned reference diverges from public ordinal/score/geometry/near evidence')
        result['published_ordered_digests_matched'] = True
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pin', choices=PINS.keys(), required=True)
    parser.add_argument('--input-dir', type=Path, help='Directory with the two checksum-pinned WORD/LAYOUT gzip files')
    parser.add_argument('--motifs', type=int, default=10000)
    parser.add_argument('--options', type=int, default=24)
    parser.add_argument('--batch', type=int, default=524288)
    parser.add_argument('--threads', type=int, default=12)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError(args.out)
    result = run(args)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'input_commit', 'all_rows_compared_elementwise',
                                             'positives', 'boundary_records')}))


if __name__ == '__main__':
    main()
