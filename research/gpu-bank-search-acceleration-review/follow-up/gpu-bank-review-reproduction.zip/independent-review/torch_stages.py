"""Decompose the historical PyTorch CUDA path using fresh processes and actual legacy batches.

Run with an absent --out directory. The untouched control and extra synchronization in
the staged run are timed separately. Neither run changes input files or process clocks.
"""
from time import perf_counter
PROCESS_ENTRY = perf_counter()

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
CODEX = ROOT.parent.parent
ORIGINAL = CODEX / 'multibank-latest-round-20261119'
SNAPSHOT = CODEX / 'gpu-cpu-search-pilot-20261119/snapshot-172475c2/complex'
KAPPA = '0.00387561167742'
EXPECTED = {
    'WORD.json.gz': '341c49e9b9d6e8742f948cba2407f7ad67164f87f4191c21319730cfc8b419d3',
    'LAYOUT.json.gz': '5bd55b71fd1757a2c907bdc2a32f69e29b38f960fa95b67780842502888e2364',
}
COMPARED = ('baseline_graph', 'kappa', 'total_connected_motifs', 'nonexcluded_motifs',
            'selected_motifs', 'options_limit', 'assignments_scored',
            'uncertain_or_positive_assignments_checked_by_exact_histogram', 'unique_histograms',
            'positive_examples')


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def args_for(path):
    return ['--graph', str(SNAPSHOT / 'WORD.json.gz'), '--layout', str(SNAPSHOT / 'LAYOUT.json.gz'),
            '--kappa', KAPPA, '--out', str(path), '--motifs', '10000', '--backend', 'cuda']


def snapshot_gpu():
    fields = 'name,driver_version,pstate,clocks.current.sm,clocks.current.memory,utilization.gpu,memory.used,power.draw'
    cmd = ['nvidia-smi', '--query-gpu=' + fields, '--format=csv,nounits']
    try:
        return dict(at=now(), command=cmd, result=subprocess.check_output(cmd, text=True, timeout=5).strip())
    except (OSError, subprocess.SubprocessError) as error:
        return dict(at=now(), command=cmd, error=str(error))


def staged(out):
    before = perf_counter()
    import numpy as np
    after_np = perf_counter()
    import torch
    after_torch = perf_counter()
    sys.path.insert(0, str(ORIGINAL))
    import fused_search as legacy
    after_legacy = perf_counter()
    rows = []
    probe = {}
    unwrapped_as_tensor = torch.as_tensor
    synced = torch.cuda.synchronize

    def first_table(tensor, *args, **kwargs):
        if kwargs.get('device') != 'cuda':
            return unwrapped_as_tensor(tensor, *args, **kwargs)
        # This is the very first legacy CUDA operation, actual price-table transfer before
        # any per-assignment batches. Split runtime setup from allocation and upload.
        before = perf_counter()
        torch.cuda.init()
        synced()
        after_init = perf_counter()
        # Isolate the first real allocation of the exact device table shape/dtype.
        # from_numpy and copy_ replace only the very first as_tensor call.
        host = torch.from_numpy(tensor)
        actual = torch.empty(host.shape, device='cuda', dtype=host.dtype)
        synced()
        after_alloc = perf_counter()
        actual.copy_(host)
        synced()
        after_upload = perf_counter()
        probe.update(init_and_sync_s=after_init-before,
                     first_device_table_alloc_and_sync_s=after_alloc-after_init,
                     table_upload_and_sync_s=after_upload-after_alloc,
                     table_shape=list(tensor.shape), table_bytes=int(tensor.nbytes))
        torch.as_tensor = unwrapped_as_tensor
        return actual

    def score(cs, base, weights, olds, table, backend):
        if backend != 'cuda':
            raise ValueError(backend)
        n = len(base)
        input_bytes = sum(x.nbytes for x in (cs, base, weights, olds))
        t0 = perf_counter()
        cs = torch.as_tensor(cs, device='cuda')
        value = torch.as_tensor(base, device='cuda')
        w = torch.as_tensor(weights, device='cuda')
        old = torch.as_tensor(olds, device='cuda')
        synced()
        t1 = perf_counter()
        changed = cs != old
        if not rows:
            synced()
            probe['first_chart_comparison_kernel_and_sync_s'] = perf_counter() - t1
        legal = changed.sum(1) >= 3
        del changed
        for j, (u, v) in enumerate(legacy.PAIRS):
            term = table[cs[:, u], cs[:, v]]
            legal &= (w[:, j] == 0) | (term != legacy.INVALID)
            value += term * w[:, j]
        scores = torch.where(legal, value, legacy.INVALID)
        synced()
        t2 = perf_counter()
        returned = scores.cpu().numpy()
        t3 = perf_counter()
        rows.append(dict(rows=n, input_bytes=input_bytes, output_bytes=returned.nbytes,
                         h2d_s=t1-t0, score_s=t2-t1, d2h_s=t3-t2))
        return returned

    torch.as_tensor = first_table
    legacy.batch_score = score
    # Supplying the original args reproduces the exact generation, row packing, scoring
    # invocations, CPU near-boundary checks and original report-writing path.
    sys.argv = [str(ORIGINAL / 'fused_search.py'), *args_for(out / 'staged')]
    t0 = perf_counter()
    try:
        legacy.main()
    finally:
        torch.as_tensor = unwrapped_as_tensor
    legacy_time = perf_counter() - t0
    props = torch.cuda.get_device_properties(0)
    stage_names = ('h2d_s', 'score_s', 'd2h_s')
    full_sums = {key: sum(r[key] for r in rows) for key in stage_names}
    full_sums['stage_total_s'] = sum(full_sums.values())
    after_first = {key: sum(r[key] for r in rows[1:]) for key in stage_names}
    config_keys = ('CUDA_MODULE_LOADING','CUDA_LAUNCH_BLOCKING','CUDA_CACHE_DISABLE','CUDA_CACHE_MAXSIZE',
                   'CUDA_VISIBLE_DEVICES','PYTORCH_CUDA_ALLOC_CONF','PYTORCH_ALLOC_CONF','OMP_NUM_THREADS',
                   'MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','CUDA_FORCE_PTX_JIT','CUDA_DISABLE_PTX_JIT')
    meta = dict(python=sys.version, executable=sys.executable, platform=platform.platform(),
                cpu=platform.processor(), os_cpu_count=os.cpu_count(), numpy=np.__version__,
                torch=torch.__version__, torch_cuda_runtime=torch.version.cuda, torch_git=torch.version.git_version,
                cuda_device=props.name, major_minor=[props.major,props.minor], gpu_memory=props.total_memory,
                torch_intraop_threads=torch.get_num_threads(), torch_interop_threads=torch.get_num_interop_threads(),
                torch_compiled_arch_list=torch.cuda.get_arch_list(),
                config={key:os.environ.get(key) for key in config_keys})
    write(out / 'stages.json', dict(import_setup_s=before-PROCESS_ENTRY, numpy_import_s=after_np-before,
          torch_import_s=after_torch-after_np, remaining_legacy_import_s=after_legacy-after_torch,
          legacy_main_s=legacy_time, first=probe, batch_count=len(rows), batches=rows, stage_sums=full_sums,
          sums_after_first_batch=after_first, meta=meta))


def run_pair(out):
    out.mkdir(parents=True, exist_ok=False)
    checked = {name:sha(SNAPSHOT/name) for name in EXPECTED}
    if checked != EXPECTED:
        raise ValueError(f'fixed compressed bytes did not match: {checked}')
    historical = json.loads((ORIGINAL / 'cold-full-benchmark.json').read_bytes())['runs']
    old_ref = [r for r in historical if r['backend'] == 'cuda']
    bench_source = ROOT / 'results/counterbalanced/benchmark.json'
    bench = json.loads(bench_source.read_bytes())
    matched = [r for r in bench['runs'] if r['backend'] == 'cuda']
    def stats(values):
        return dict(median=statistics.median(values), min=min(values), max=max(values), samples=values)
    summary = dict(start=now(), graph=str(SNAPSHOT), fixed=checked,
                   script_sha256=sha(Path(__file__)), old_scorer_sha256=sha(ORIGINAL/'fused_search.py'),
                   inputs_from=bench['benchmark_commit'], historical_wall_s=stats([r['process_wall_s'] for r in old_ref]),
                   historical_torch_batch_total_s=stats([r['report']['gpu_transfer_score_return_s'] for r in old_ref]),
                   matched_wall_s=stats([r['process_wall_s'] for r in matched]),
                   matched_torch_batch_total_s=stats([json.loads((bench_source.parent/r['report_file']).read_bytes())
                                                      ['gpu_transfer_score_return_s'] for r in matched]), runs=[])
    output = out / 'diagnostic.json'
    write(output, summary)
    for mode in ('untouched','staged'):
        if mode == 'untouched':
            cmd = [sys.executable,'-I','-B',str(ORIGINAL/'fused_search.py'),*args_for(out / mode)]
        else:
            cmd = [sys.executable,'-I','-B',str(Path(__file__).resolve()),'--staged-worker','--out',str(out)]
        state = dict(mode=mode, command=cmd, gpu_before=snapshot_gpu(), utc=now(), exit_code=None)
        summary['runs'].append(state)
        write(output, summary)
        t = perf_counter()
        with (out/(mode+'.log')).open('wb') as handle:
            try:
                p = subprocess.run(cmd, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT, timeout=55)
            except subprocess.TimeoutExpired:
                state.update(timed_out=True, wall_s=perf_counter()-t)
                write(output, summary)
                raise
        state.update(exit_code=p.returncode, wall_s=perf_counter()-t, gpu_after=snapshot_gpu())
        write(output, summary)
        p.check_returncode()
    untouched, staged_report = [json.loads((out/mode/'report.json').read_bytes()) for mode in ('untouched','staged')]
    upstream_report = old_ref[0]['report']
    summary['outputs_agree'] = all(untouched[k] == staged_report[k] == upstream_report[k] for k in COMPARED)
    if not summary['outputs_agree']:
        write(output, summary)
        raise ValueError('legacy decisions or census changed')
    s = json.loads((out/'stages.json').read_bytes())
    if sum(row['rows'] for row in s['batches']) != untouched['assignments_scored']:
        raise ValueError('incomplete staged coverage')
    summary.update(end=now(), first=s['first'], imports_s={k:v for k,v in s.items() if 'import' in k},
                   first_batch=s['batches'][0], remaining_batches=s['sums_after_first_batch'],
                   staged_total=s['stage_sums'], staged_report_score_s=staged_report['gpu_transfer_score_return_s'],
                   untouched_score_s=untouched['gpu_transfer_score_return_s'],
                   scope='Wall timings with extra synchronizations at stage boundaries; the first real table transfer is split into context initialization, allocation and copy. Subsequent eager scoring operations use identical data and dispatch expressions. Per-stage host time includes synchronization and launch overhead. Snapshot GPU load/clocks cannot reconstruct between-sample behavior. Historical run lacks staged observations. One diagnostic pair is not a benchmark of the new path.')
    write(output, summary)
    print(json.dumps({k:summary[k] for k in ('first','first_batch','remaining_batches','staged_total','untouched_score_s','outputs_agree')}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--staged-worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    (staged if args.staged_worker else run_pair)(args.out.resolve())

