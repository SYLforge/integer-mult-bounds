"""CPU-only NumPy scoring using grouped compact descriptors and pair-factor tables.

Each slab contains motifs with similar option lengths. Permuting axes for the
calculation allows motifs with equivalent shapes to share a native SIMD loop.
The original Cartesian coordinates, ordinals and scores are restored exactly.
"""

from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
import math
import os
from pathlib import Path
import sys
from time import perf_counter

import numpy as np

FROZEN = Path(__file__).resolve().parent / 'review-633e1db0/work/benchmark'
if str(FROZEN) not in sys.path:
    sys.path.insert(0, str(FROZEN))
from gpu_score import _pack

INVALID = -10**14
PAIRS = list(combinations(range(4), 2))
PAIR_IDS = np.zeros((4, 4), dtype=np.int32)
for _j, (_u, _v) in enumerate(PAIRS):
    PAIR_IDS[_u, _v] = PAIR_IDS[_v, _u] = _j


def _buckets(values):
    # Bound padding while combining many physically equivalent axis orderings.
    bins = np.array([1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256])
    bucket = np.searchsorted(bins, values)
    return np.where(bucket == len(bins), values, bins[np.minimum(bucket, len(bins)-1)])


class _Plan:
    def __init__(self, arrays):
        self.prefix, self.meta, self.baseline, self.options, self.exterior, self.table = arrays
        self.symmetric = np.array_equal(self.table, self.table.T)
        self.perm = np.argsort(self.meta[:, :4], axis=1, kind='stable')
        self.dims = np.take_along_axis(self.meta[:, :4], self.perm, axis=1)
        self.boxes = _buckets(self.dims)
        self.offsets = np.take_along_axis(self.meta[:, 4:8], self.perm, axis=1)
        self.original = np.take_along_axis(self.meta[:, 8:12], self.perm, axis=1)
        orig_strides = np.ones((len(self.meta), 4), dtype=np.int64)
        for i in (2, 1, 0):
            orig_strides[:, i] = orig_strides[:, i+1] * self.meta[:, i+1]
        self.strides = np.take_along_axis(orig_strides, self.perm, axis=1)
        self.weights = [self.meta[np.arange(len(self.meta)), 12+PAIR_IDS[self.perm[:, u], self.perm[:, v]]]
                        for u, v in PAIRS]

    def jobs(self, first, end, slab_size):
        lo = int(self.prefix.searchsorted(first, side='right'))-1
        hi = int(self.prefix.searchsorted(end, side='left'))
        groups = defaultdict(list)
        for m in range(lo, hi):
            groups[tuple(self.boxes[m].tolist())].append(m)
        for dims, group in groups.items():
            entries = max(1, slab_size // math.prod(dims))
            for start in range(0, len(group), entries):
                yield dims, np.array(group[start:start+entries], dtype=np.intp)

    def slab(self, job, first, end, audit_out):
        dims, motifs = job
        charts, partial, moved = [], [], []
        for j, n in enumerate(dims):
            index = np.arange(n, dtype=np.int32)
            limits = self.dims[motifs, j, None]
            positions = self.offsets[motifs, j, None] + np.minimum(index, limits-1)
            chosen = self.options[positions]
            charts.append(chosen)
            partial.append(self.exterior[positions])
            # A padded index represents no Cartesian assignment.
            moved.append(np.where(index < limits, chosen != self.original[motifs, j, None], -8).astype(np.int8))

        # Three-variable terms are accumulated on a small prefix grid; only
        # the remaining pair terms need to broadcast along all four axes.
        v3 = (partial[0] - self.baseline[motifs, None])[:, :, None, None] + partial[1][:, None, :, None]
        v3 = v3 + partial[2][:, None, None, :]
        legal3 = np.ones(v3.shape, dtype=np.bool_)
        last_terms = []
        for j, (a, b) in enumerate(PAIRS):
            weights = self.weights[j][motifs]
            if not weights.any():
                continue
            term = self.table[charts[a][:, :, None], charts[b][:, None, :]]
            if not self.symmetric:
                flipped = self.perm[motifs, a] > self.perm[motifs, b]
                if flipped.any():
                    term[flipped] = self.table[charts[b][flipped, None, :], charts[a][flipped, :, None]]
            legal = (term != INVALID) | (weights[:, None, None] == 0)
            contribution = term * weights[:, None, None]
            axes = [len(motifs)] + [1] * (3 if b < 3 else 4)
            axes[a+1], axes[b+1] = dims[a], dims[b]
            if b < 3:
                v3 += contribution.reshape(axes)
                legal3 &= legal.reshape(axes)
            else:
                last_terms.append((contribution.reshape(axes), legal.reshape(axes)))
        values = v3[..., None] + partial[3][:, None, None, None, :]
        changes = moved[0][:, :, None, None] + moved[1][:, None, :, None] + moved[2][:, None, None, :]
        legal = (changes[..., None] + moved[3][:, None, None, None, :]) >= 3
        legal &= legal3[..., None]
        for contribution, valid_pair in last_terms:
            values += contribution
            legal &= valid_pair
        np.copyto(values, INVALID, where=~legal)
        threshold = -self.meta[motifs, 18].astype(np.int64) - 2
        pos = np.nonzero(values >= threshold[:, None, None, None, None])
        near = []
        if len(pos[0]):
            picked = motifs[pos[0]]
            ordinals = sum(pos[a+1] * self.strides[picked, a] for a in range(4))
            # Mask explicitly in case an alternate fixture supplies a threshold
            # below INVALID; padding duplicates must never become assignments.
            real = np.logical_and.reduce([pos[a+1] < self.dims[picked, a] for a in range(4)])
            absolute = self.prefix[picked].astype(np.int64) + ordinals
            keep = real & (absolute >= first) & (absolute < end)
            near = list(zip(picked[keep].tolist(), ordinals[keep].tolist(), values[pos][keep].tolist()))

        if audit_out is not None:
            all_charts, all_scores = audit_out
            for i, m in enumerate(motifs):
                start = int(self.prefix[m]); stop = int(self.prefix[m+1]); dims_m = self.dims[m]
                lo, hi = max(first, start), min(end, stop)
                if hi <= lo:
                    continue
                cropped = values[i][tuple(slice(int(length)) for length in dims_m)]
                original = cropped.transpose(np.argsort(self.perm[m])).reshape(-1)
                target = slice(lo-first, hi-first)
                off = slice(lo-start, hi-start)
                all_scores[target] = original[off]
                real_shape = tuple(map(int, self.meta[m, :4]))
                complete = lo == start and hi == stop
                for a, original_axis in enumerate(self.perm[m]):
                    shape = [1, 1, 1, 1]
                    shape[original_axis] = int(dims_m[a])
                    coordinate = charts[a][i, :dims_m[a]].reshape(shape)
                    if complete:
                        all_charts[target, original_axis].reshape(real_shape)[...] = coordinate
                    else:
                        all_charts[target, original_axis] = np.broadcast_to(coordinate, real_shape).reshape(-1)[off]
        return near


def score_selected(selected, old, table, on_near, *, on_audit=None, batch_size=524288, threads=12,
                   slab_size=131072):
    """Deliver the same ordered near and full-audit callbacks as GPU score_selected."""
    if not (1 <= batch_size <= 2**29-1 and 1 <= threads <= 256 and slab_size >= 1):
        raise ValueError('invalid batch size, thread count or slab size')
    start = perf_counter()
    arrays, total = _pack(selected, old, table)
    packed = perf_counter()
    stats = dict(assignments_scored=total, descriptor_packing_s=packed-start, threads=threads,
                 backend='grouped NumPy CPU', numpy=np.__version__, cpu_logical_processors=os.cpu_count(),
                 compilation='installed NumPy native binary, no experiment-specific build or saved search cache',
                 batch_size=batch_size, batch_count=0, boundary_hits=0, slab_size=slab_size)
    if not total:
        return stats
    plan = _Plan(arrays)
    prepared = perf_counter()
    stats['cpu_group_metadata_s'] = prepared - packed
    # Production stores only sparse hits. Bound full audit buffers to around
    # 32 MB and retain the caller's contiguous callback window boundaries.
    window = total if on_audit is None else max(1, 1572864 // batch_size) * batch_size
    with ThreadPoolExecutor(max_workers=threads) as pool:
        for first in range(0, total, window):
            end = min(total, first+window)
            outputs = None if on_audit is None else (np.empty((end-first, 4), dtype=np.int32),
                                                      np.empty(end-first, dtype=np.int64))
            jobs = plan.jobs(first, end, slab_size)
            def evaluate(job):
                return plan.slab(job, first, end, outputs)
            groups = pool.map(evaluate, jobs) if threads > 1 else map(evaluate, jobs)
            near = sorted(record for group in groups for record in group)
            which = 0
            for block in range(first, end, batch_size):
                stop = min(end, block+batch_size)
                before = which
                while which < len(near):
                    m, z, _ = near[which]
                    if int(plan.prefix[m]) + z >= stop:
                        break
                    which += 1
                if which > before:
                    on_near(near[before:which])
                if outputs is not None:
                    segment = slice(block-first, stop-first)
                    on_audit(block, outputs[0][segment], outputs[1][segment])
                stats['batch_count'] += 1
            stats['boundary_hits'] += len(near)
    stats['pipeline_wall_s'] = perf_counter() - prepared
    stats['scorer_wall_s'] = perf_counter() - start
    return stats
